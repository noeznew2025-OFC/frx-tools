FRX TOOLS v3.0 - Grafik, Crosshair, Booster, Screenshot, Floating (Shizuku) by FaruqExe
1. Install & jalankan Shizuku di HP (via Wireless Debugging / root).
2. Buka folder ini di Android Studio -> Sync -> Build > Build APK(s).
3. Install APK, buka, kasih izin Shizuku, pilih game/preset/LOD.

BUILD LEWAT GITHUB (tanpa PC)
1. Buat repo baru di github.com, upload SEMUA isi folder ini (termasuk folder .github).
2. Buka tab Actions > Build APK > tunggu hijau.
3. Download artifact FRX-TOOLS-APK, extract, install app-debug.apk.

FITUR v3.0: Floating FRX (bubble + panel), Crosshair (warna/bentuk/ukuran/posisi),
Clear cache (animasi), Screenshot (Pictures/FRX-Screenshots), tombol EXIT.
Izin yang dibutuhkan: Tampil di atas aplikasi lain, Shizuku, notifikasi.

v3.1: menu floating baru (slide-up dari bawah, tombol bulat + ikon), panel fitur di kanan
yang bisa digeser, crosshair default OFF, app dipecah jadi menu/halaman, ada halaman Informasi.

v3.2: koneksi Shizuku lebih tahan banting (mode service + mode langsung, status & tombol hubungkan ulang),
Game Library + Mode Game, statistik, HUD monitor, DND, tema warna, animasi BOOST otomatis dari floating.
