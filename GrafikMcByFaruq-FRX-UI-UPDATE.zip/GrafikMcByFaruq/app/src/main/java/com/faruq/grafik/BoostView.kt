package com.faruq.grafik

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.sin

/** Animasi cincin ala game booster: ring progres + tick berputar + persen di tengah. */
class BoostView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val rect = RectF()
    private var sweep: SweepGradient? = null
    private var state = 0 // 0 idle, 1 running, 2 done
    private var progress = 0f
    private var angle = 0f
    private var progAnim: ValueAnimator? = null
    private var rotAnim: ValueAnimator? = null

    private fun startRot() {
        rotAnim?.cancel()
        rotAnim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 1100
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { angle = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun start() {
        state = 1
        progress = 0f
        progAnim?.cancel()
        progAnim = ValueAnimator.ofFloat(0f, 0.92f).apply {
            duration = 3500
            interpolator = DecelerateInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
        startRot()
    }

    fun finish() {
        progAnim?.cancel()
        progAnim = ValueAnimator.ofFloat(progress, 1f).apply {
            duration = 450
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) {
                    state = 2
                    rotAnim?.cancel()
                    rotAnim = null
                    invalidate()
                }
            })
            start()
        }
    }

    fun reset() {
        progAnim?.cancel()
        rotAnim?.cancel()
        rotAnim = null
        state = 0
        progress = 0f
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (state == 1 && rotAnim == null) startRot()
    }

    override fun onDetachedFromWindow() {
        rotAnim?.cancel()
        rotAnim = null
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        sweep = SweepGradient(w / 2f, h / 2f, intArrayOf(Theme.PURPLE, Theme.CYAN, Theme.PURPLE), null)
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = minOf(cx, cy) - 14 * d

        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 8 * d
        paint.color = Theme.BORDER
        c.drawCircle(cx, cy, r, paint)

        if (state == 2) {
            paint.color = Theme.GREEN
            c.drawCircle(cx, cy, r, paint)
        } else if (progress > 0f) {
            rect.set(cx - r, cy - r, cx + r, cy + r)
            paint.shader = sweep
            paint.strokeCap = Paint.Cap.ROUND
            c.save()
            c.rotate(-90f, cx, cy)
            c.drawArc(rect, 0f, 360f * progress, false, paint)
            c.restore()
            paint.shader = null
            paint.strokeCap = Paint.Cap.BUTT
        }

        if (state == 1) {
            val n = 24
            val ro = r - 18 * d
            val ri = ro - 7 * d
            paint.strokeWidth = 3 * d
            c.save()
            c.rotate(angle, cx, cy)
            for (i in 0 until n) {
                paint.color = Color.argb(30 + 225 * i / n, 0, 229, 255)
                val a = Math.toRadians(i * 360.0 / n)
                val ca = cos(a).toFloat()
                val sa = sin(a).toFloat()
                c.drawLine(cx + ri * ca, cy + ri * sa, cx + ro * ca, cy + ro * sa, paint)
            }
            c.restore()
        }

        paint.textAlign = Paint.Align.CENTER
        when (state) {
            1 -> {
                paint.style = Paint.Style.FILL
                paint.color = Theme.TXT
                paint.textSize = 28 * d
                c.drawText("${(progress * 100).toInt()}%", cx, cy + 10 * d, paint)
            }
            2 -> {
                val p = Path()
                p.moveTo(cx - r * 0.32f, cy)
                p.lineTo(cx - r * 0.08f, cy + r * 0.24f)
                p.lineTo(cx + r * 0.34f, cy - r * 0.22f)
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 6 * d
                paint.strokeCap = Paint.Cap.ROUND
                paint.strokeJoin = Paint.Join.ROUND
                paint.color = Theme.GREEN
                c.drawPath(p, paint)
                paint.strokeCap = Paint.Cap.BUTT
            }
            else -> {
                paint.style = Paint.Style.FILL
                paint.color = Theme.TXT
                paint.textSize = 20 * d
                c.drawText("BOOST", cx, cy + 7 * d, paint)
            }
        }
        paint.textAlign = Paint.Align.LEFT
    }
}
