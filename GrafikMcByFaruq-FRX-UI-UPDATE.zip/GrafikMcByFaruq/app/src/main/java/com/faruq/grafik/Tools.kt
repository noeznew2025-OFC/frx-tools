package com.faruq.grafik

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BoostResult(
    val ok: Boolean, val ramBefore: Long, val ramAfter: Long,
    val storBefore: Long, val storAfter: Long
) {
    fun summary(): String {
        if (!ok) return "Shizuku belum terhubung. Buka app FRX TOOLS dan beri izin."
        val cache = (storAfter - storBefore).coerceAtLeast(0)
        return "Cache dibersihkan: $cache MB\nRAM tersedia: $ramBefore → $ramAfter MB"
    }
}

data class Stats(
    val ramFreeMb: Long, val ramTotalMb: Long,
    val batPct: Int, val batTemp: Float,
    val cpuTemp: Float?, val cpuPct: Int?
)

object Tools {
    private var lastCpu: LongArray? = null

    fun ramTotalMb(): Long = try {
        File("/proc/meminfo").readLines()
            .first { it.startsWith("MemTotal:") }
            .filter { it.isDigit() }.toLong() / 1024
    } catch (_: Exception) { 0L }

    /** Statistik. withShell=true menambah CPU% dan suhu CPU lewat Shizuku. Panggil dari thread background. */
    fun stats(ctx: Context, withShell: Boolean): Stats {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val bt = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f

        var cpuT: Float? = null
        var cpuP: Int? = null
        if (withShell && ShellBridge.ready) {
            val out = ShellBridge.exec(
                "head -1 /proc/stat; for z in /sys/class/thermal/thermal_zone*; do echo \"T:\$(cat \$z/type 2>/dev/null):\$(cat \$z/temp 2>/dev/null)\"; done"
            )
            var best = -1f
            for (line in out.lines()) {
                if (line.startsWith("cpu ")) {
                    val n = line.trim().split(Regex("\\s+")).drop(1).mapNotNull { it.toLongOrNull() }
                    if (n.size >= 5) {
                        val total = n.take(8).sum()
                        val idle = n[3] + n[4]
                        val prev = lastCpu
                        if (prev != null && total > prev[0]) {
                            val dt = total - prev[0]
                            val di = idle - prev[1]
                            cpuP = (100 * (dt - di) / dt).toInt().coerceIn(0, 100)
                        }
                        lastCpu = longArrayOf(total, idle)
                    }
                } else if (line.startsWith("T:")) {
                    val parts = line.split(":")
                    if (parts.size >= 3) {
                        val type = parts[1].lowercase()
                        var v = parts[2].trim().toFloatOrNull() ?: continue
                        if (v > 1000f) v /= 1000f
                        if (v in 10f..120f && (type.contains("cpu") || type.contains("soc") || type.contains("tsens"))) {
                            if (v > best) best = v
                        }
                    }
                }
            }
            if (best > 0f) cpuT = best
        }
        return Stats(memAvailMb(), ramTotalMb(), pct, bt, cpuT, cpuP)
    }

    /** Aktif/nonaktifkan Jangan Ganggu lewat shell. Return true kalau sukses. */
    fun setDnd(on: Boolean): Boolean {
        if (!ShellBridge.ready) return false
        return if (on) {
            ShellBridge.exec("cmd notification set_dnd priority")
            if (ShellBridge.exec("settings get global zen_mode").trim() == "0") {
                ShellBridge.exec("settings put global zen_mode 1")
            }
            ShellBridge.exec("settings get global zen_mode").trim() != "0"
        } else {
            ShellBridge.exec("cmd notification set_dnd off")
            ShellBridge.exec("settings put global zen_mode 0")
            true
        }
    }

    private const val SHOT_DIR = "/sdcard/Pictures/FRX-Screenshots"

    fun memAvailMb(): Long = try {
        File("/proc/meminfo").readLines()
            .first { it.startsWith("MemAvailable:") }
            .filter { it.isDigit() }.toLong() / 1024
    } catch (_: Exception) { 0L }

    fun freeStorageMb(): Long = try {
        StatFs(Environment.getDataDirectory().path).availableBytes / 1048576
    } catch (_: Exception) { 0L }

    /** Bersihkan cache semua aplikasi + matikan proses latar belakang. Harus dipanggil dari thread background. */
    fun boost(): BoostResult {
        if (!ShellBridge.ready) return BoostResult(false, 0, 0, 0, 0)
        val rb = memAvailMb()
        val sb = freeStorageMb()
        ShellBridge.exec("pm trim-caches 999G")
        ShellBridge.exec("am kill-all")
        Thread.sleep(1500)
        return BoostResult(true, rb, memAvailMb(), sb, freeStorageMb())
    }

    /** Ambil screenshot. Return path file kalau berhasil, null kalau gagal. Thread background. */
    fun screenshot(ctx: Context): String? {
        if (!ShellBridge.ready) return null
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val path = "$SHOT_DIR/FRX_$ts.png"
        ShellBridge.exec("mkdir -p $SHOT_DIR")
        ShellBridge.exec("screencap -p $path")
        val ok = ShellBridge.exec("test -s $path && echo OK").trim() == "OK"
        if (!ok) return null
        MediaScannerConnection.scanFile(ctx.applicationContext, arrayOf(path), arrayOf("image/png"), null)
        return path
    }
}

object Runner {
    fun grafik(ctx: Context, onResult: (String) -> Unit, block: (Grafik) -> Unit) {
        val app = ctx.applicationContext
        if (!ShellBridge.ready) {
            ShellBridge.bind(app)
            onResult("Belum terhubung ke Shizuku. Buka app FRX TOOLS dan beri izin.")
            return
        }
        Thread {
            val sb = StringBuilder()
            val g = Grafik(
                { ShellBridge.exec(it) },
                app.getSharedPreferences("faruq", Context.MODE_PRIVATE),
                { sb.appendLine(it) }
            )
            try { block(g) } catch (e: Exception) { sb.appendLine("ERROR: ${e.message}") }
            Handler(Looper.getMainLooper()).post { onResult(sb.toString().trim()) }
        }.start()
    }
}
