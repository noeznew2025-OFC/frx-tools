package com.faruq.grafik

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.faruq.grafik.Theme.BG
import com.faruq.grafik.Theme.BORDER
import com.faruq.grafik.Theme.CARD
import com.faruq.grafik.Theme.CYAN
import com.faruq.grafik.Theme.GREEN
import com.faruq.grafik.Theme.MUTED
import com.faruq.grafik.Theme.PURPLE
import com.faruq.grafik.Theme.RED
import com.faruq.grafik.Theme.TXT
import java.util.Locale
import rikka.shizuku.Shizuku

private class MenuItem(
    val title: String,
    val desc: String,
    val icon: Int,
    val ring: Int,
    val action: () -> Unit
)

class MainActivity : Activity() {

    companion object {
        const val DEV = "FaruqExe"
        const val TIKTOK = "https://tiktok.com/@faruqexe"
        const val WA = "https://whatsapp.com/channel/0029VbDuMJcBadmisROLuF18"
        const val VERSION = "3.2"
        val ORANGE = Color.parseColor("#FF9100")
        val LILAC = Color.parseColor("#B39DFF")
        val PRESETS = listOf("smooth", "pixel", "retro")
    }

    private lateinit var ui: Ui
    private val handler = Handler(Looper.getMainLooper())

    // state yang bertahan antar halaman
    private var statusMsg = "Menghubungkan ke Shizuku…"
    private var detailMsg = "Menunggu Shizuku…"
    private var statusOk = false
    private var curDot: View? = null
    private var curText: TextView? = null
    private var curDetail: TextView? = null
    private var logText = "Menunggu perintah…"
    private var logView: TextView? = null
    private var floatBtn: TextView? = null
    private var shotInfo: TextView? = null
    private var statRam: TextView? = null
    private var statBat: TextView? = null
    private var statTemp: TextView? = null
    private var onHome = true
    private var resumed = false
    private var launching = false
    private var gameIdx = 1
    private var presetIdx = 0
    private var lodIdx = 1

    private val binderL = Shizuku.OnBinderReceivedListener { checkShizuku(false) }
    private val deadL = Shizuku.OnBinderDeadListener { checkShizuku(false) }
    private val permL = Shizuku.OnRequestPermissionResultListener { _, _ -> checkShizuku(false) }

    // ---------- helpers ----------
    private fun dp(v: Int) = ui.dp(v)
    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = ui.text(t, size, color, bold)
    private fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0) = ui.lp(w, h, top, bottom)
    private fun rounded(c: Int, r: Int, s: Int = 0) = ui.rounded(c, r, s)
    private fun prefs() = getSharedPreferences("frx_ui", MODE_PRIVATE)

    private fun card(title: String?, content: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(CARD, 20, BORDER)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        if (title != null) {
            addView(text(title.uppercase(), 11f, MUTED, true).apply { letterSpacing = 0.12f }, lp(-2, -2, 0, 10))
        }
        addView(content)
    }

    private fun logoView(sizeDp: Int): ImageView = ImageView(this).apply {
        setImageResource(R.drawable.ic_logo_fg)
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#120A2E"), Color.parseColor("#3B1FB8"), PURPLE)
        ).apply { shape = GradientDrawable.OVAL; setStroke(dp(2), CYAN) }
        layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
    }

    private fun paintStatus() {
        curText?.text = statusMsg
        curDetail?.text = detailMsg
        curDot?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (statusOk) GREEN else RED)
        }
    }

    private fun setStatus(t: String, ok: Boolean, detail: String? = null) {
        statusMsg = t
        statusOk = ok
        if (detail != null) detailMsg = detail
        paintStatus()
    }

    private fun log(t: String) {
        logText = t
        logView?.text = t
    }

    private fun statusPill(): View {
        val dot = View(this)
        val t = text(statusMsg, 12f, TXT, true)
        curDot = dot
        curText = t
        val pill = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(CARD, 24, BORDER)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            addView(dot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginEnd = dp(8) })
            addView(t)
        }
        paintStatus()
        return pill
    }

    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
        catch (e: Exception) { Toast.makeText(this, "Tidak bisa membuka link", Toast.LENGTH_SHORT).show() }
    }

    private fun rootBox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(20), dp(16), dp(24))
    }

    private fun setScreen(content: View) {
        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(content)
        })
    }

    // ---------- Shizuku ----------
    /** Periksa koneksi Shizuku dan tampilkan status yang jelas. */
    private fun checkShizuku(manual: Boolean) = runOnUiThread {
        if (!ShellBridge.alive()) {
            setStatus(
                "Shizuku belum berjalan",
                false,
                "Buka aplikasi Shizuku, tekan Start, lalu kembali ke sini dan tekan HUBUNGKAN ULANG."
            )
        } else if (!ShellBridge.granted()) {
            val denied = try { Shizuku.shouldShowRequestPermissionRationale() } catch (_: Throwable) { false }
            if (denied) {
                setStatus(
                    "Izin Shizuku ditolak",
                    false,
                    "Buka Shizuku > Aplikasi terotorisasi, lalu izinkan FRX TOOLS."
                )
            } else {
                setStatus("Menunggu izin Shizuku…", false, "Setujui dialog izin yang muncul.")
                try { Shizuku.requestPermission(1) } catch (_: Throwable) {}
            }
        } else {
            ShellBridge.bind(this, manual)
            setStatus(
                "Shizuku terhubung",
                true,
                "Mode: ${ShellBridge.mode} • uid ${ShellBridge.uid()} • versi ${ShellBridge.version()}"
            )
        }
    }

    private fun openShizuku() {
        val i = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (i != null) startActivity(i)
        else Toast.makeText(this, "Aplikasi Shizuku belum terpasang", Toast.LENGTH_LONG).show()
    }

    private fun runG(block: (Grafik) -> Unit) {
        if (!ShellBridge.ready) {
            log("Belum terhubung ke Shizuku.")
            checkShizuku(true)
            return
        }
        log("Memproses…")
        Runner.grafik(this, { log(it) }, block)
    }

    // ---------- floating ----------
    private fun refreshFloatBtn() {
        floatBtn?.text = if (OverlayService.running) "MATIKAN FLOATING FRX" else "AKTIFKAN FLOATING FRX"
    }

    private fun startFloating(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Izinkan \"Tampil di atas aplikasi lain\" untuk FRX TOOLS, lalu tekan tombol lagi.",
                Toast.LENGTH_LONG
            ).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        return true
    }

    private fun toggleFloating() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_EXIT))
        } else if (!startFloating()) return
        handler.postDelayed({ refreshFloatBtn() }, 600)
    }

    private fun screenshotDelayed() {
        if (!ShellBridge.ready) {
            shotInfo?.text = "Belum terhubung ke Shizuku."
            checkShizuku(true)
            return
        }
        Toast.makeText(this, "Pindah ke layar yang mau di-screenshot, 3 detik lagi", Toast.LENGTH_SHORT).show()
        handler.postDelayed({
            Thread {
                val path = try { Tools.screenshot(this) } catch (e: Exception) { null }
                handler.post {
                    val msg = if (path != null) "Tersimpan di galeri:\n" + path.removePrefix("/sdcard/")
                    else "Screenshot gagal. Pastikan Shizuku aktif."
                    shotInfo?.text = msg
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            }.start()
        }, 3000)
    }

    // ---------- Game library ----------
    private fun saveGames(l: List<String>) {
        prefs().edit().putString("games", l.joinToString(",")).apply()
    }

    private fun loadGames(): MutableList<String> {
        val raw = prefs().getString("games", null)
        if (raw == null) {
            val def = Grafik.GAMES.values
                .filter { packageManager.getLaunchIntentForPackage(it) != null }
                .toMutableList()
            saveGames(def)
            return def
        }
        return raw.split(",").filter { it.isNotBlank() }.toMutableList()
    }

    private fun addGame(pkg: String) {
        val l = loadGames()
        if (!l.contains(pkg)) l.add(pkg)
        saveGames(l)
        Toast.makeText(this, "Ditambahkan ke Game Library", Toast.LENGTH_SHORT).show()
        showHome()
    }

    private fun removeGame(pkg: String) {
        val l = loadGames()
        l.remove(pkg)
        saveGames(l)
        showHome()
    }

    private fun labelOf(pkg: String): String = try {
        packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    private fun gameRow(pkg: String): View {
        val icon = ImageView(this).apply {
            try { setImageDrawable(packageManager.getApplicationIcon(pkg)) } catch (_: Exception) {}
        }
        val names = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text(labelOf(pkg), 14f, TXT, true).apply { maxLines = 1 })
            addView(text(pkg, 10f, MUTED).apply { maxLines = 1 })
        }
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(Theme.CHIP, 18, BORDER)
            setPadding(dp(10), dp(8), dp(10), dp(8))
            addView(icon, LinearLayout.LayoutParams(dp(44), dp(44)))
            addView(names, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
            addView(
                ui.roundButton(R.drawable.ic_x, MUTED, 30, 8) { removeGame(pkg) },
                LinearLayout.LayoutParams(dp(30), dp(30)).apply { marginEnd = dp(8) }
            )
            addView(
                ui.roundButton(R.drawable.ic_play, PURPLE, 42, 11) { playGame(pkg) },
                LinearLayout.LayoutParams(dp(42), dp(42))
            )
        }
    }

    private fun libraryBox(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val games = loadGames()
        if (games.isEmpty()) {
            box.addView(text("Belum ada game. Tambahkan dari daftar aplikasi.", 12f, MUTED), lp(-1, -2, 0, 10))
        }
        for (g in games) box.addView(gameRow(g), lp(-1, -2, 0, 8))
        box.addView(ui.outlineButton("+ TAMBAH GAME", CYAN, Theme.CHIP, 12f, 12) { openPicker() })
        return box
    }

    private fun optRow(label: String, key: String, def: Boolean): View {
        lateinit var pill: TextView
        fun paint() {
            val on = prefs().getBoolean(key, def)
            pill.text = if (on) "ON" else "OFF"
            pill.setTextColor(if (on) Color.WHITE else MUTED)
            pill.background = rounded(if (on) PURPLE else Theme.CHIP, 16, if (on) PURPLE else BORDER)
        }
        pill = text("", 11f, TXT, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(6), dp(14), dp(6))
            setOnClickListener {
                prefs().edit().putBoolean(key, !prefs().getBoolean(key, def)).apply()
                paint()
            }
        }
        paint()
        return LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(text(label, 13f, TXT), LinearLayout.LayoutParams(0, -2, 1f))
            addView(pill)
        }
    }

    private fun modeGameBox(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        box.addView(optRow("Bersihkan RAM / cache", "g_boost", true), lp(-1, -2, 0, 10))
        box.addView(optRow("Nyalakan floating FRX", "g_float", true), lp(-1, -2, 0, 10))
        box.addView(optRow("Jangan Ganggu (DND)", "g_dnd", false), lp(-1, -2, 0, 10))
        box.addView(optRow("Terapkan grafik terakhir (FF / FF MAX)", "g_gfx", false))
        box.addView(
            text("Dijalankan otomatis saat tombol ▶ pada game ditekan, lalu game dibuka.", 11f, MUTED),
            lp(-1, -2, 12, 0)
        )
        return box
    }

    private fun playGame(pkg: String) {
        if (launching) return
        launching = true
        val o = prefs()
        val doBoost = o.getBoolean("g_boost", true)
        val doFloat = o.getBoolean("g_float", true)
        val doDnd = o.getBoolean("g_dnd", false)
        val doGfx = o.getBoolean("g_gfx", false)
        val gameName = Grafik.GAMES.entries.firstOrNull { it.value == pkg }?.key
        val preset = PRESETS[presetIdx.coerceIn(0, 2)]
        val lod = lodIdx + 1
        Toast.makeText(this, "Menyiapkan Mode Game…", Toast.LENGTH_SHORT).show()
        Thread {
            if (ShellBridge.ready) {
                if (doDnd) Tools.setDnd(true)
                if (doGfx && gameName != null) {
                    val g = Grafik(
                        { ShellBridge.exec(it) },
                        getSharedPreferences("faruq", MODE_PRIVATE),
                        { }
                    )
                    g.apply(gameName, preset, lod)
                }
                if (doBoost) Tools.boost()
            }
            handler.post {
                launching = false
                if (doFloat && !OverlayService.running && Settings.canDrawOverlays(this)) {
                    startForegroundService(Intent(this, OverlayService::class.java))
                }
                val li = packageManager.getLaunchIntentForPackage(pkg)
                if (li != null) startActivity(li)
                else Toast.makeText(this, "Game tidak bisa dibuka", Toast.LENGTH_SHORT).show()
                refreshFloatBtn()
            }
        }.start()
    }

    // ---------- stats ----------
    private val statsTick = object : Runnable {
        override fun run() {
            if (!onHome || !resumed) return
            val s = Tools.stats(this@MainActivity, false)
            statRam?.text = String.format(Locale.US, "%.1f GB", s.ramFreeMb / 1024f)
            statBat?.text = "${s.batPct}%"
            statTemp?.text = String.format(Locale.US, "%.0f°C", s.batTemp)
            handler.postDelayed(this, 3000)
        }
    }

    private fun statChip(title: String): Pair<View, TextView> {
        val v = text("-", 15f, TXT, true)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(CARD, 18, BORDER)
            setPadding(dp(8), dp(10), dp(8), dp(10))
            addView(text(title, 10f, MUTED, true).apply { letterSpacing = 0.1f })
            addView(v, lp(-2, -2, 2, 0))
        }
        return Pair(box, v)
    }

    // ---------- HOME ----------
    private fun menuCard(mi: MenuItem): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        background = ui.ripple(rounded(CARD, 22, BORDER))
        setPadding(dp(10), dp(16), dp(10), dp(16))
        addView(ui.roundButton(mi.icon, mi.ring, 58, 15) { mi.action() }, LinearLayout.LayoutParams(dp(58), dp(58)))
        addView(text(mi.title, 14f, TXT, true).apply { gravity = Gravity.CENTER; letterSpacing = 0.06f }, lp(-2, -2, 10, 0))
        addView(text(mi.desc, 11f, MUTED).apply { gravity = Gravity.CENTER }, lp(-1, -2, 3, 0))
        setOnClickListener { mi.action() }
    }

    private fun connCard(): View {
        val detail = text(detailMsg, 11f, MUTED)
        curDetail = detail
        val row = LinearLayout(this)
        row.addView(
            ui.outlineButton("HUBUNGKAN ULANG", CYAN, Theme.CHIP, 11f, 11) { checkShizuku(true) },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        row.addView(
            ui.outlineButton("BUKA SHIZUKU", GREEN, Theme.CHIP, 11f, 11) { openShizuku() },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) }
        )
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(statusPill())
            addView(detail, lp(-1, -2, 8, 10))
            addView(row)
        }
        paintStatus()
        return card("Koneksi Shizuku", box)
    }

    private fun showHome() {
        onHome = true
        logView = null
        shotInfo = null
        val root = rootBox()

        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("FRX TOOLS", 24f, TXT, true).apply { letterSpacing = 0.1f })
            addView(text("Game Space • v$VERSION", 12f, CYAN, true))
            addView(text("by $DEV", 12f, MUTED))
        }
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(logoView(68))
            addView(titles, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(14) })
        }
        root.addView(header, lp(-1, -2, 0, 14))

        // statistik
        val ram = statChip("RAM BEBAS")
        val bat = statChip("BATERAI")
        val tmp = statChip("SUHU")
        statRam = ram.second; statBat = bat.second; statTemp = tmp.second
        val statRow = LinearLayout(this)
        statRow.addView(ram.first, LinearLayout.LayoutParams(0, -2, 1f))
        statRow.addView(bat.first, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        statRow.addView(tmp.first, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) })
        root.addView(statRow, lp(-1, -2, 0, 12))

        root.addView(connCard(), lp(-1, -2, 0, 12))

        // Floating
        val fb = ui.gradientButton("AKTIFKAN FLOATING FRX") { toggleFloating() }
        floatBtn = fb
        val floatBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(
                text("Logo FRX mengambang di atas game. Ketuk untuk membuka menu: Grafik, Crosshair, Boost, Screenshot, DND, Monitor, dan Exit.", 12f, MUTED),
                lp(-1, -2, 0, 10)
            )
            addView(fb)
        }
        root.addView(card("Floating FRX", floatBox), lp(-1, -2, 0, 12))

        // Game library + mode game
        root.addView(card("Game Library", libraryBox()), lp(-1, -2, 0, 12))
        root.addView(card("Mode Game", modeGameBox()), lp(-1, -2, 0, 16))

        // Menu
        root.addView(text("MENU", 11f, MUTED, true).apply { letterSpacing = 0.12f }, lp(-2, -2, 0, 8))
        val items = listOf(
            MenuItem("GRAFIK", "Preset, LOD, perbandingan", R.drawable.ic_grafik, PURPLE) { openGrafik() },
            MenuItem("CROSSHAIR", "Warna, bentuk, ukuran", R.drawable.ic_cross, GREEN) { openCross() },
            MenuItem("CLEAR CACHE", "Bersihkan cache & RAM", R.drawable.ic_boost, ORANGE) { openBoost() },
            MenuItem("SCREENSHOT", "Simpan ke galeri", R.drawable.ic_shot, CYAN) { openShot() },
            MenuItem("TEMA", "Ganti warna aplikasi", R.drawable.ic_theme, Theme.RED) { openTheme() },
            MenuItem("INFORMASI", "Tentang & cara pakai", R.drawable.ic_info, LILAC) { openInfo() }
        )
        items.chunked(2).forEachIndexed { r, pair ->
            val row = LinearLayout(this)
            pair.forEachIndexed { c, mi ->
                row.addView(
                    menuCard(mi),
                    LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.MATCH_PARENT, 1f)
                        .apply { if (c > 0) marginStart = dp(10) }
                )
            }
            root.addView(row, lp(-1, -2, if (r > 0) 10 else 0, 0))
        }

        // Developer
        root.addView(card(null, developerBox()), lp(-1, -2, 18, 14))
        root.addView(text("© FRX TOOLS • $DEV", 11f, MUTED).apply { gravity = Gravity.CENTER }, lp(-1, -2))

        setScreen(root)
        refreshFloatBtn()
        handler.removeCallbacks(statsTick)
        if (resumed) handler.post(statsTick)
    }

    private fun developerBox(): View {
        val social = LinearLayout(this)
        social.addView(
            ui.outlineButton("TikTok", Color.parseColor("#FE2C55"), Color.parseColor("#1A0A12")) { openUrl(TIKTOK) },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        social.addView(
            ui.outlineButton("Saluran WhatsApp", Color.parseColor("#25D366"), Color.parseColor("#0A1A12")) { openUrl(WA) },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) }
        )
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("DEVELOPER", 11f, MUTED, true).apply { letterSpacing = 0.12f })
            addView(text(DEV, 20f, TXT, true), lp(-2, -2, 2, 12))
            addView(social)
        }
    }

    // ---------- halaman ----------
    private fun showPage(title: String, icon: Int, ring: Int, content: View) {
        onHome = false
        val root = rootBox()
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bar.addView(ui.roundButton(R.drawable.ic_back, ring, 44, 11) { showHome() }, LinearLayout.LayoutParams(dp(44), dp(44)))
        bar.addView(
            text(title, 20f, TXT, true).apply { letterSpacing = 0.08f },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(12) }
        )
        bar.addView(
            ui.roundButton(icon, ring, 38, 9) {}.apply { isClickable = false },
            LinearLayout.LayoutParams(dp(38), dp(38))
        )
        root.addView(bar, lp(-1, -2, 0, 12))
        root.addView(statusPill(), lp(-2, -2, 0, 14))
        root.addView(content)
        setScreen(root)
    }

    private fun openGrafik() = showPage("GRAFIK", R.drawable.ic_grafik, PURPLE, pageGrafik())
    private fun openCross() = showPage("CROSSHAIR", R.drawable.ic_cross, GREEN, pageCross())
    private fun openBoost() = showPage("CLEAR CACHE", R.drawable.ic_boost, ORANGE, pageBoost())
    private fun openShot() = showPage("SCREENSHOT", R.drawable.ic_shot, CYAN, pageShot())
    private fun openTheme() = showPage("TEMA", R.drawable.ic_theme, Theme.RED, pageTheme())
    private fun openInfo() = showPage("INFORMASI", R.drawable.ic_info, LILAC, pageInfo())
    private fun openPicker() = showPage("TAMBAH GAME", R.drawable.ic_plus, CYAN, pagePicker())

    private fun pageGrafik(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val game = ui.Chips(Grafik.GAMES.keys.toList(), gameIdx)
        val preset = ui.Chips(PRESETS, presetIdx)
        val lod = ui.Chips(listOf("1", "2", "3", "4"), lodIdx)
        game.onChange = { gameIdx = game.idx }
        box.addView(card("Game", game.view), lp(-1, -2, 0, 12))
        box.addView(card("Preset grafik", preset.view), lp(-1, -2, 0, 12))
        box.addView(card("Level LOD", lod.view), lp(-1, -2, 0, 12))

        // Perbandingan (simulasi)
        val descs = listOf("Tekstur halus, tepi lembut.", "Tekstur kotak-kotak tajam.", "Pixel tajam, warna terbatas, garis scanline.")
        val prevViews = PRESETS.map { PreviewView(this) }
        val frames = PRESETS.map { LinearLayout(this).apply { setPadding(dp(3), dp(3), dp(3), dp(3)) } }
        val cmp = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val refreshPreview = {
            val l = lod.value.toInt()
            prevViews.forEachIndexed { i, pv ->
                pv.set(PRESETS[i], l)
                frames[i].background =
                    if (i == preset.idx) ui.rounded(Color.TRANSPARENT, 15, PURPLE, 2)
                    else ui.rounded(Color.TRANSPARENT, 15, BORDER)
            }
        }
        PRESETS.forEachIndexed { i, p ->
            frames[i].addView(prevViews[i], LinearLayout.LayoutParams(-1, -2))
            frames[i].setOnClickListener { preset.select(i); presetIdx = i; refreshPreview() }
            cmp.addView(frames[i], lp(-1, -2, if (i == 0) 0 else 12, 6))
            cmp.addView(LinearLayout(this).apply {
                addView(text(p.uppercase(), 12f, TXT, true).apply { letterSpacing = 0.1f })
                addView(text("  •  ${descs[i]}", 12f, MUTED))
            })
        }
        cmp.addView(
            text("Simulasi ilustrasi. Hasil asli di game bisa beda tergantung ROM dan game. Tap gambar untuk memilih preset.", 11f, MUTED),
            lp(-1, -2, 12, 0)
        )
        preset.onChange = { presetIdx = preset.idx; refreshPreview() }
        lod.onChange = { lodIdx = lod.idx; refreshPreview() }
        refreshPreview()
        box.addView(card("Perbandingan grafik", cmp), lp(-1, -2, 0, 16))

        // Aksi
        box.addView(ui.gradientButton("TERAPKAN GRAFIK") {
            val g = game.value
            val p = preset.value
            val l = lod.value.toInt()
            runG { it.apply(g, p, l) }
        }, lp(-1, -2, 0, 10))
        val row = LinearLayout(this)
        fun add(v: View, first: Boolean) =
            row.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { if (!first) marginStart = dp(8) })
        add(ui.outlineButton("CEK", CYAN, Theme.CHIP) { runG { it.checkDevice() } }, true)
        add(ui.outlineButton("OFF", RED, Theme.CHIP) { val g = game.value; runG { it.off(g) } }, false)
        add(ui.outlineButton("STATUS", GREEN, Theme.CHIP) { val g = game.value; runG { it.status(g) } }, false)
        box.addView(row, lp(-1, -2, 0, 16))

        // Log
        val lv = text(logText, 12f, GREEN).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setLineSpacing(0f, 1.25f)
        }
        logView = lv
        val term = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#05050C"), 16, BORDER)
            setPadding(dp(14), dp(12), dp(14), dp(14))
            addView(text("LOG", 11f, MUTED, true).apply { letterSpacing = 0.12f }, lp(-2, -2, 0, 6))
            addView(lv)
        }
        box.addView(term)
        return box
    }

    private fun pageCross(): View =
        card("Pengaturan crosshair", CrossControls.build(ui, CrossCfg.prefs(this), false))

    private fun pageBoost(): View = card("Clear cache", BoostControls.build(ui))

    private fun pageShot(): View {
        val info = text("Hasil disimpan di Pictures/FRX-Screenshots dan muncul di galeri.", 12f, MUTED)
        shotInfo = info
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(
                text("Tekan tombol, lalu pindah ke layar yang mau di-screenshot. Dari floating FRX, tombol SCREENSHOT langsung menyembunyikan menu dan mengambil gambar.", 12f, MUTED),
                lp(-1, -2, 0, 12)
            )
            addView(ui.gradientButton("SCREENSHOT (TUNDA 3 DETIK)", 14f, 14) { screenshotDelayed() })
            addView(info, lp(-1, -2, 12, 0))
        }
        return card("Screenshot", box)
    }

    private fun pageTheme(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        Theme.THEMES.forEachIndexed { i, t ->
            val selected = i == Theme.index
            val dot1 = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(t.a) }
            }
            val dot2 = View(this).apply {
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(t.b) }
            }
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = ui.ripple(rounded(CARD, 20, if (selected) t.a else BORDER))
                setPadding(dp(16), dp(14), dp(16), dp(14))
                addView(dot1, LinearLayout.LayoutParams(dp(26), dp(26)))
                addView(dot2, LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginStart = dp(-8) })
                addView(text(t.name, 15f, TXT, true), LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(14) })
                if (selected) addView(text("AKTIF", 11f, t.a, true))
                setOnClickListener {
                    Theme.save(this@MainActivity, i)
                    window.statusBarColor = BG
                    openTheme()
                }
            }
            box.addView(row, lp(-1, -2, 0, 10))
        }
        box.addView(
            text("Warna berlaku di app. Untuk floating, warna baru terpakai saat floating dinyalakan ulang.", 11f, MUTED),
            lp(-1, -2, 4, 0)
        )
        return box
    }

    @Suppress("DEPRECATION")
    private fun pagePicker(): View {
        val pm = packageManager
        val li = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(li, 0)
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val search = EditText(this).apply {
            hint = "Cari aplikasi / game…"
            setHintTextColor(MUTED)
            setTextColor(TXT)
            textSize = 14f
            background = rounded(CARD, 16, BORDER)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            isSingleLine = true
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun fill(q: String) {
            list.removeAllViews()
            val f = apps.filter {
                q.isBlank() || it.first.contains(q, true) || it.second.contains(q, true)
            }.take(80)
            if (f.isEmpty()) list.addView(text("Tidak ada hasil.", 12f, MUTED))
            for (a in f) {
                val icon = ImageView(this).apply {
                    try { setImageDrawable(pm.getApplicationIcon(a.second)) } catch (_: Exception) {}
                }
                val names = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    addView(text(a.first, 14f, TXT, true).apply { maxLines = 1 })
                    addView(text(a.second, 10f, MUTED).apply { maxLines = 1 })
                }
                val row = LinearLayout(this).apply {
                    gravity = Gravity.CENTER_VERTICAL
                    background = ui.ripple(rounded(CARD, 16, BORDER))
                    setPadding(dp(10), dp(8), dp(10), dp(8))
                    addView(icon, LinearLayout.LayoutParams(dp(38), dp(38)))
                    addView(names, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(10) })
                    setOnClickListener { addGame(a.second) }
                }
                list.addView(row, lp(-1, -2, 0, 8))
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { fill(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        fill("")
        box.addView(search, lp(-1, -2, 0, 12))
        box.addView(list)
        return box
    }

    private fun infoCard(title: String, body: String): View =
        card(title, text(body, 13f, TXT).apply { setLineSpacing(0f, 1.2f) })

    private fun pageInfo(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun add(title: String, body: String) = box.addView(infoCard(title, body), lp(-1, -2, 0, 12))

        add("Tentang", "FRX TOOLS v$VERSION\nDeveloper: $DEV\nGame space untuk grafik, crosshair, boost, screenshot, dan monitor, dijalankan lewat Shizuku.")
        add(
            "Fitur",
            "• GAME LIBRARY: daftar game pilihan lo. Tekan ▶ untuk Mode Game lalu buka game.\n" +
                "• MODE GAME: otomatis bersihkan RAM, nyalakan floating, DND, dan terapkan grafik sebelum game dibuka.\n" +
                "• GRAFIK: ANGLE (preset smooth / pixel / retro dan LOD 1-4) untuk Free Fire biasa atau MAX, plus simulasi perbandingan.\n" +
                "• CROSSHAIR: warna, bentuk, ukuran, ketebalan, transparansi, posisi. Default mati, aktifkan dari floating.\n" +
                "• CLEAR CACHE: bersihkan cache dan proses latar belakang dengan animasi.\n" +
                "• SCREENSHOT: hasil masuk galeri (Pictures/FRX-Screenshots).\n" +
                "• FLOATING: bubble menempel di tepi layar. Menu bawah berisi statistik dan tombol Grafik, Crosshair, Boost, Screenshot, DND, Monitor, Exit.\n" +
                "• MONITOR: HUD CPU, RAM, baterai, dan suhu di atas layar.\n" +
                "• TEMA: ganti warna aplikasi."
        )
        add(
            "Cara pakai",
            "1. Nyalakan Shizuku (Wireless Debugging atau root).\n" +
                "2. Buka FRX TOOLS dan beri izin Shizuku. Status harus hijau.\n" +
                "3. Tambahkan game ke Game Library, lalu tekan ▶.\n" +
                "4. Untuk floating: izinkan \"Tampil di atas aplikasi lain\"."
        )
        add(
            "Kalau Shizuku tidak terhubung",
            "• Pastikan Shizuku berstatus Running.\n" +
                "• Tekan HUBUNGKAN ULANG di halaman utama.\n" +
                "• Cek Shizuku > Aplikasi terotorisasi, FRX TOOLS harus diizinkan.\n" +
                "• Kalau Shizuku baru di-restart, tutup lalu buka lagi FRX TOOLS.\n" +
                "• Baris detail di kartu Koneksi menunjukkan mode dan versi Shizuku."
        )
        add(
            "Catatan penting",
            "• ANGLE bergantung pada ROM. Kalau ROM tidak punya driver ANGLE, pengaturan tersimpan tapi tidak ada efek.\n" +
                "• Status \"tersimpan\" bukan bukti FPS naik.\n" +
                "• Clear cache tanpa root terbatas pada cache aplikasi dan proses latar belakang.\n" +
                "• DND dan suhu CPU bergantung pada ROM, bisa tidak tersedia di sebagian HP.\n" +
                "• Overlay crosshair di game kompetitif berisiko dianggap tidak adil. Pakai dengan risiko sendiri."
        )
        val abi = Build.SUPPORTED_ABIS.firstOrNull() ?: "-"
        add(
            "Perangkat ini",
            "Merek: ${Build.MANUFACTURER}\nModel: ${Build.MODEL}\nAndroid: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})\nArsitektur: $abi\n" +
                "Shizuku: ${if (ShellBridge.ready) "terhubung (${ShellBridge.mode})" else "belum terhubung"}\n" +
                "Izin overlay: ${if (Settings.canDrawOverlays(this)) "aktif" else "belum diberikan"}"
        )
        box.addView(card(null, developerBox()))
        return box
    }

    // ---------- lifecycle ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Theme.load(this)
        ui = Ui(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)

        ShellBridge.onChange = { checkShizuku(false) }
        showHome()

        Shizuku.addBinderReceivedListenerSticky(binderL)
        Shizuku.addBinderDeadListener(deadL)
        Shizuku.addRequestPermissionResultListener(permL)

        // cek berulang beberapa detik pertama supaya status tidak nyangkut
        for (t in longArrayOf(300, 1200, 3000, 6000)) handler.postDelayed({ checkShizuku(false) }, t)
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (!onHome) showHome() else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        resumed = true
        refreshFloatBtn()
        checkShizuku(false)
        if (onHome) {
            handler.removeCallbacks(statsTick)
            handler.post(statsTick)
        }
    }

    override fun onPause() {
        resumed = false
        handler.removeCallbacks(statsTick)
        super.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        ShellBridge.onChange = null
        Shizuku.removeBinderReceivedListener(binderL)
        Shizuku.removeBinderDeadListener(deadL)
        Shizuku.removeRequestPermissionResultListener(permL)
    }
}
