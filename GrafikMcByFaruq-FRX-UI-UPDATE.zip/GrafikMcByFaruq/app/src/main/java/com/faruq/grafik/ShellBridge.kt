package com.faruq.grafik

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/**
 * Satu pintu ke shell Shizuku.
 * Mode 1: UserService (cepat). Mode 2: langsung via newProcess (cadangan kalau UserService gagal di HP tertentu).
 */
object ShellBridge {
    @Volatile var svc: IShellService? = null
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile private var lastBind = 0L

    fun alive(): Boolean = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
    fun granted(): Boolean = try {
        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    val direct: Boolean get() = alive() && granted()
    val ready: Boolean get() = svc != null || direct
    val mode: String get() = if (svc != null) "service" else if (direct) "langsung" else "-"

    fun uid(): Int = try { Shizuku.getUid() } catch (_: Throwable) { -1 }
    fun version(): Int = try { Shizuku.getVersion() } catch (_: Throwable) { -1 }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            svc = IShellService.Stub.asInterface(b)
            onChange?.invoke()
        }
        override fun onServiceDisconnected(n: ComponentName?) {
            svc = null
            onChange?.invoke()
        }
    }

    private fun args(ctx: Context) =
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, ShellService::class.java.name))
            .daemon(false).processNameSuffix("shell").debuggable(false).version(1)

    fun bind(ctx: Context, force: Boolean = false) {
        if (svc != null) return
        val now = System.currentTimeMillis()
        if (!force && now - lastBind < 3000) return
        lastBind = now
        try {
            if (direct) Shizuku.bindUserService(args(ctx.applicationContext), conn)
        } catch (_: Throwable) {}
    }

    fun exec(cmd: String): String {
        val s = svc
        if (s != null) {
            try { return s.exec(cmd) } catch (_: Exception) { svc = null }
        }
        return if (direct) runDirect(cmd) else "ERR: Shizuku belum terhubung"
    }

    private fun runDirect(cmd: String): String = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        out.trim()
    } catch (e: Throwable) {
        "ERR: ${e.cause?.message ?: e.message ?: e.javaClass.simpleName}"
    }
}
