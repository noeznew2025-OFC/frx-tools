FRX TOOLS v3.0 - Grafik, Crosshair, Booster, Screenshot, Floating (Shizuku) by FaruqExe
1. Install & jalankan Shizuku di HP (via Wireless Debugging / root).
2. Buka folder ini di Android Studio -> Sync -> Build > Build APK(s).
3. Install APK, buka, kasih izin Shizuku, pilih game/preset/LOD.

BUILD LEWAT GITHUB (tanpa PC)
1. Buat repo baru di github.com, upload SEMUA isi folder ini (termasuk folder .github).
2. Buka tab Actions > Build APK > tunggu hijau.
3. Download artifact FRX-TOOLS-APK, extract, install app-debug.apk.

FITUR v3.0: Floating FRX (bubble + panel), Crosshair (warna/bentuk/ukuran/posisi),
Clear cache (animasi), Screenshot (Pictures/FRX-Screenshots), tombol EXIT.
Izin yang dibutuhkan: Tampil di atas aplikasi lain, Shizuku, notifikasi.
