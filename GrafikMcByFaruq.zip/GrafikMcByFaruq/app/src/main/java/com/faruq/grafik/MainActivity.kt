package com.faruq.grafik

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.faruq.grafik.Theme.BG
import com.faruq.grafik.Theme.BORDER
import com.faruq.grafik.Theme.CARD
import com.faruq.grafik.Theme.CYAN
import com.faruq.grafik.Theme.GREEN
import com.faruq.grafik.Theme.MUTED
import com.faruq.grafik.Theme.PURPLE
import com.faruq.grafik.Theme.RED
import com.faruq.grafik.Theme.TXT
import rikka.shizuku.Shizuku

class MainActivity : Activity() {

    companion object {
        const val DEV = "FaruqExe"
        const val TIKTOK = "https://tiktok.com/@faruqexe"
        const val WA = "https://whatsapp.com/channel/0029VbDuMJcBadmisROLuF18"
    }

    private lateinit var ui: Ui
    private lateinit var logView: TextView
    private lateinit var statusText: TextView
    private lateinit var statusDot: View
    private lateinit var floatBtn: TextView
    private lateinit var shotInfo: TextView
    private lateinit var gameChips: Ui.Chips
    private lateinit var presetChips: Ui.Chips
    private lateinit var lodChips: Ui.Chips
    private val handler = Handler(Looper.getMainLooper())

    private val binderL = Shizuku.OnBinderReceivedListener { ensureShizuku() }
    private val permL = Shizuku.OnRequestPermissionResultListener { _, r ->
        if (r == PackageManager.PERMISSION_GRANTED) ShellBridge.bind(this)
        else runOnUiThread { setStatus("Izin Shizuku ditolak", false) }
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = ui.dp(v)
    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = ui.text(t, size, color, bold)
    private fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0) = ui.lp(w, h, top, bottom)
    private fun rounded(c: Int, r: Int, s: Int = 0) = ui.rounded(c, r, s)

    private fun card(title: String?, content: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = rounded(CARD, 18, BORDER)
        setPadding(dp(16), dp(14), dp(16), dp(16))
        if (title != null) {
            addView(text(title.uppercase(), 11f, MUTED, true).apply { letterSpacing = 0.12f }, lp(-2, -2, 0, 10))
        }
        addView(content)
    }

    private fun setStatus(t: String, ok: Boolean) {
        statusText.text = t
        statusDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (ok) GREEN else RED)
        }
    }

    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
        catch (e: Exception) { Toast.makeText(this, "Tidak bisa membuka link", Toast.LENGTH_SHORT).show() }
    }

    // ---------- Shizuku ----------
    private fun ensureShizuku() = runOnUiThread {
        if (!Shizuku.pingBinder()) {
            setStatus("Shizuku belum berjalan", false)
            logView.text = "Buka aplikasi Shizuku dan start dulu."
        } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            ShellBridge.bind(this)
        } else {
            Shizuku.requestPermission(1)
        }
    }

    private fun runG(block: (Grafik) -> Unit) {
        if (!ShellBridge.ready) {
            logView.text = "Belum terhubung ke Shizuku."
            ensureShizuku()
            return
        }
        logView.text = "Memproses…"
        Runner.grafik(this, { logView.text = it }, block)
    }

    // ---------- floating ----------
    private fun refreshFloatBtn() {
        floatBtn.text = if (OverlayService.running) "MATIKAN FLOATING FRX" else "AKTIFKAN FLOATING FRX"
    }

    private fun toggleFloating() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_EXIT))
        } else {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Izinkan \"Tampil di atas aplikasi lain\" untuk FRX TOOLS, lalu tekan tombol lagi.", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                return
            }
            startForegroundService(Intent(this, OverlayService::class.java))
        }
        handler.postDelayed({ refreshFloatBtn() }, 600)
    }

    private fun screenshotDelayed() {
        if (!ShellBridge.ready) {
            shotInfo.text = "Belum terhubung ke Shizuku."
            ensureShizuku()
            return
        }
        Toast.makeText(this, "Pindah ke game, screenshot dalam 3 detik", Toast.LENGTH_SHORT).show()
        handler.postDelayed({
            Thread {
                val path = try { Tools.screenshot(this) } catch (e: Exception) { null }
                handler.post {
                    val msg = if (path != null) "Tersimpan di:\n" + path.removePrefix("/sdcard/")
                    else "Screenshot gagal. Pastikan Shizuku aktif."
                    shotInfo.text = msg
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            }.start()
        }, 3000)
    }

    // ---------- screen ----------
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = Ui(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(24))
        }

        // Header
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_logo_fg)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#120A2E"), Color.parseColor("#3B1FB8"), PURPLE)
            ).apply { cornerRadius = dp(18).toFloat(); setStroke(dp(1), BORDER) }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(2), dp(2), dp(2), dp(2))
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("FRX TOOLS", 24f, TXT, true).apply { letterSpacing = 0.1f })
            addView(text("Grafik • Crosshair • Boost • v3.0", 12f, CYAN, true))
            addView(text("by $DEV", 12f, MUTED))
        }
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(logo, LinearLayout.LayoutParams(dp(68), dp(68)))
            addView(titles, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(14) })
        }
        root.addView(header, lp(-1, -2, 0, 16))

        // Status pill
        statusDot = View(this)
        statusText = text("Menghubungkan ke Shizuku…", 12f, TXT, true)
        val pill = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            background = rounded(CARD, 20, BORDER)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            addView(statusDot, LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginEnd = dp(8) })
            addView(statusText)
        }
        root.addView(pill, lp(-2, -2, 0, 12))

        // Floating
        floatBtn = ui.gradientButton("AKTIFKAN FLOATING FRX") { toggleFloating() }
        val floatBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("Logo FRX mengambang di atas game: Grafik, Crosshair, Boost, Screenshot, dan tombol EXIT.", 12f, MUTED), lp(-1, -2, 0, 10))
            addView(floatBtn)
        }
        root.addView(card("Floating FRX", floatBox), lp(-1, -2, 0, 12))

        // Grafik
        gameChips = ui.Chips(Grafik.GAMES.keys.toList(), 1)
        presetChips = ui.Chips(listOf("smooth", "pixel", "retro"), 0)
        lodChips = ui.Chips(listOf("1", "2", "3", "4"), 1)
        root.addView(card("Game", gameChips.view), lp(-1, -2, 0, 12))
        root.addView(card("Preset grafik", presetChips.view), lp(-1, -2, 0, 12))
        root.addView(card("Level LOD", lodChips.view), lp(-1, -2, 0, 12))

        // Perbandingan grafik (simulasi)
        val presets = listOf("smooth", "pixel", "retro")
        val descs = listOf("Tekstur halus, tepi lembut.", "Tekstur kotak-kotak tajam.", "Pixel tajam, warna terbatas, garis scanline.")
        val prevViews = presets.map { PreviewView(this) }
        val frames = presets.map { LinearLayout(this).apply { setPadding(dp(3), dp(3), dp(3), dp(3)) } }
        val cmp = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val refreshPreview = {
            val l = lodChips.value.toInt()
            prevViews.forEachIndexed { i, pv ->
                pv.set(presets[i], l)
                frames[i].background =
                    if (i == presetChips.idx) ui.rounded(Color.TRANSPARENT, 15, PURPLE, 2)
                    else ui.rounded(Color.TRANSPARENT, 15, BORDER)
            }
        }
        presets.forEachIndexed { i, p ->
            frames[i].addView(prevViews[i], LinearLayout.LayoutParams(-1, -2))
            frames[i].setOnClickListener { presetChips.select(i); refreshPreview() }
            cmp.addView(frames[i], lp(-1, -2, if (i == 0) 0 else 12, 6))
            cmp.addView(LinearLayout(this).apply {
                addView(text(p.uppercase(), 12f, TXT, true).apply { letterSpacing = 0.1f })
                addView(text("  •  ${descs[i]}", 12f, MUTED))
            })
        }
        cmp.addView(text("Simulasi ilustrasi. Hasil asli di game bisa beda tergantung ROM dan game. Tap gambar untuk memilih preset.", 11f, MUTED), lp(-1, -2, 12, 0))
        presetChips.onChange = refreshPreview
        lodChips.onChange = refreshPreview
        refreshPreview()
        root.addView(card("Perbandingan grafik", cmp), lp(-1, -2, 0, 16))

        // Aksi grafik
        root.addView(ui.gradientButton("TERAPKAN GRAFIK") {
            val p = presetChips.value
            val l = lodChips.value.toInt()
            val g = gameChips.value
            runG { it.apply(g, p, l) }
        }, lp(-1, -2, 0, 10))
        val row = LinearLayout(this)
        fun add(v: View, first: Boolean) =
            row.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { if (!first) marginStart = dp(8) })
        add(ui.outlineButton("CEK", CYAN, Theme.CHIP) { runG { it.checkDevice() } }, true)
        add(ui.outlineButton("OFF", RED, Theme.CHIP) { val g = gameChips.value; runG { it.off(g) } }, false)
        add(ui.outlineButton("STATUS", GREEN, Theme.CHIP) { val g = gameChips.value; runG { it.status(g) } }, false)
        root.addView(row, lp(-1, -2, 0, 16))

        // Crosshair
        root.addView(card("Crosshair", CrossControls.build(ui, CrossCfg.prefs(this))), lp(-1, -2, 0, 12))

        // Boost / clear cache
        root.addView(card("Clear cache", BoostControls.build(ui)), lp(-1, -2, 0, 12))

        // Screenshot
        shotInfo = text("Hasil disimpan di Pictures/FRX-Screenshots.", 12f, MUTED)
        val shotBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(ui.outlineButton("SCREENSHOT (TUNDA 3 DETIK)", CYAN, Theme.CHIP) { screenshotDelayed() })
            addView(shotInfo, lp(-1, -2, 10, 0))
        }
        root.addView(card("Screenshot", shotBox), lp(-1, -2, 0, 16))

        // Log
        logView = text("Menunggu perintah…", 12f, GREEN).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setLineSpacing(0f, 1.25f)
        }
        val term = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.parseColor("#05050C"), 16, BORDER)
            setPadding(dp(14), dp(12), dp(14), dp(14))
            addView(text("LOG", 11f, MUTED, true).apply { letterSpacing = 0.12f }, lp(-2, -2, 0, 6))
            addView(logView, ViewGroup.LayoutParams(-1, -2))
        }
        root.addView(term, lp(-1, -2, 0, 20))

        // Developer + sosmed
        val social = LinearLayout(this)
        social.addView(
            ui.outlineButton("TikTok", Color.parseColor("#FE2C55"), Color.parseColor("#1A0A12")) { openUrl(TIKTOK) },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        social.addView(
            ui.outlineButton("Saluran WhatsApp", Color.parseColor("#25D366"), Color.parseColor("#0A1A12")) { openUrl(WA) },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(8) }
        )
        val dev = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("DEVELOPER", 11f, MUTED, true).apply { letterSpacing = 0.12f })
            addView(text(DEV, 20f, TXT, true), lp(-2, -2, 2, 12))
            addView(social)
        }
        root.addView(card(null, dev), lp(-1, -2, 0, 14))
        root.addView(text("© FRX TOOLS • $DEV", 11f, MUTED).apply { gravity = Gravity.CENTER }, lp(-1, -2))

        setContentView(ScrollView(this).apply {
            setBackgroundColor(BG)
            isFillViewport = true
            addView(root)
        })

        ShellBridge.onChange = {
            runOnUiThread {
                if (ShellBridge.ready) {
                    setStatus("Shizuku terhubung", true)
                    logView.text = "Siap dipakai."
                } else setStatus("Shizuku terputus", false)
            }
        }
        if (ShellBridge.ready) setStatus("Shizuku terhubung", true)
        else setStatus("Menghubungkan ke Shizuku…", false)
        refreshFloatBtn()

        Shizuku.addBinderReceivedListenerSticky(binderL)
        Shizuku.addRequestPermissionResultListener(permL)
    }

    override fun onResume() {
        super.onResume()
        refreshFloatBtn()
        ShellBridge.bind(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        ShellBridge.onChange = null
        Shizuku.removeBinderReceivedListener(binderL)
        Shizuku.removeRequestPermissionResultListener(permL)
    }
}
