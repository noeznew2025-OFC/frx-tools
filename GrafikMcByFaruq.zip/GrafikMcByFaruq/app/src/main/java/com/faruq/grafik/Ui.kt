package com.faruq.grafik

import android.content.Context
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

object Theme {
    val BG = Color.parseColor("#0A0A14")
    val CARD = Color.parseColor("#14142A")
    val CHIP = Color.parseColor("#1C1C38")
    val BORDER = Color.parseColor("#2A2A4D")
    val PURPLE = Color.parseColor("#7C4DFF")
    val CYAN = Color.parseColor("#00E5FF")
    val TXT = Color.parseColor("#F2F2FA")
    val MUTED = Color.parseColor("#9A9AB8")
    val GREEN = Color.parseColor("#2BE38B")
    val RED = Color.parseColor("#FF5C7A")
}

data class CrossCfg(
    val style: Int, val color: Int, val size: Int, val thick: Int,
    val alpha: Int, val ox: Int, val oy: Int
) {
    companion object {
        const val FILE = "frx_cross"
        fun prefs(ctx: Context): SharedPreferences =
            ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

        fun load(p: SharedPreferences) = CrossCfg(
            p.getInt("c_style", 1),
            p.getInt("c_color", Color.parseColor("#00E5FF")),
            p.getInt("c_size", 36),
            p.getInt("c_thick", 2),
            p.getInt("c_alpha", 100),
            p.getInt("c_ox", 0),
            p.getInt("c_oy", 0)
        )
    }
}

class Ui(val ctx: Context) {
    fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, r: Int, stroke: Int = 0, sw: Int = 1) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(sw), stroke)
    }

    fun ripple(bg: GradientDrawable) = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, null)

    fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(color)
        typeface = if (bold) Typeface.create("sans-serif-medium", Typeface.BOLD) else Typeface.SANS_SERIF
    }

    fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    fun gradientButton(t: String, size: Float = 15f, pad: Int = 16, onClick: () -> Unit) = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        letterSpacing = 0.1f
        setPadding(0, dp(pad), 0, dp(pad))
        background = ripple(
            GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Theme.PURPLE, Color.parseColor("#00B8D4"))
            ).apply { cornerRadius = dp(14).toFloat() }
        )
        setOnClickListener { onClick() }
    }

    fun outlineButton(
        t: String, color: Int, fill: Int, size: Float = 13f, pad: Int = 14, onClick: () -> Unit
    ) = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setPadding(dp(4), dp(pad), dp(4), dp(pad))
        background = ripple(rounded(fill, 14, color))
        setOnClickListener { onClick() }
    }

    fun seek(label: String, lo: Int, hi: Int, value: Int, unit: String, onChange: (Int) -> Unit): View {
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(ctx)
        val valueView = text("$value$unit", 12f, Theme.TXT, true)
        head.addView(text(label, 12f, Theme.MUTED), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(valueView)
        val bar = SeekBar(ctx)
        bar.max = hi - lo
        bar.progress = value - lo
        bar.progressTintList = ColorStateList.valueOf(Theme.PURPLE)
        bar.thumbTintList = ColorStateList.valueOf(Theme.CYAN)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                valueView.text = "${p + lo}$unit"
                if (fromUser) onChange(p + lo)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(head)
        box.addView(bar, lp(-1, -2, 2, 0))
        return box
    }

    /** Baris/grid pilihan (chip). */
    inner class Chips(val opts: List<String>, start: Int, perRow: Int = opts.size) {
        var idx = start
        var onChange: (() -> Unit)? = null
        val value get() = opts[idx]
        private val views = mutableListOf<TextView>()
        val view = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        init {
            opts.chunked(perRow).forEachIndexed { r, rowOpts ->
                val row = LinearLayout(ctx)
                rowOpts.forEachIndexed { c, o ->
                    val i = r * perRow + c
                    val tv = text(o, 13f, Theme.MUTED, true).apply {
                        gravity = Gravity.CENTER
                        setPadding(dp(4), dp(11), dp(4), dp(11))
                        setOnClickListener { idx = i; refresh(); onChange?.invoke() }
                    }
                    row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f).apply { if (c > 0) marginStart = dp(6) })
                    views.add(tv)
                }
                repeat(perRow - rowOpts.size) {
                    row.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f).apply { marginStart = dp(6) })
                }
                view.addView(row, lp(-1, -2, if (r > 0) 6 else 0, 0))
            }
            refresh()
        }

        fun refresh() = views.forEachIndexed { i, tv ->
            if (i == idx) {
                tv.background = ripple(rounded(Theme.PURPLE, 12))
                tv.setTextColor(Color.WHITE)
            } else {
                tv.background = ripple(rounded(Theme.CHIP, 12, Theme.BORDER))
                tv.setTextColor(Theme.MUTED)
            }
        }
    }
}
