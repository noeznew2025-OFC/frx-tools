package com.faruq.grafik

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/** Satu pintu ke shell Shizuku, dipakai app dan floating overlay. */
object ShellBridge {
    @Volatile var svc: IShellService? = null
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile private var lastBind = 0L
    val ready: Boolean get() = svc != null

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            svc = IShellService.Stub.asInterface(b)
            onChange?.invoke()
        }
        override fun onServiceDisconnected(n: ComponentName?) {
            svc = null
            onChange?.invoke()
        }
    }

    private fun args(ctx: Context) =
        Shizuku.UserServiceArgs(ComponentName(ctx.packageName, ShellService::class.java.name))
            .daemon(false).processNameSuffix("shell").debuggable(false).version(1)

    fun bind(ctx: Context) {
        if (svc != null) return
        val now = System.currentTimeMillis()
        if (now - lastBind < 3000) return
        lastBind = now
        try {
            if (Shizuku.pingBinder() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            ) Shizuku.bindUserService(args(ctx.applicationContext), conn)
        } catch (_: Throwable) {}
    }

    fun exec(cmd: String): String = try {
        svc?.exec(cmd) ?: "ERR: Shizuku belum terhubung"
    } catch (e: Exception) {
        "ERR: ${e.message}"
    }
}
