package com.faruq.grafik

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BoostResult(
    val ok: Boolean, val ramBefore: Long, val ramAfter: Long,
    val storBefore: Long, val storAfter: Long
) {
    fun summary(): String {
        if (!ok) return "Shizuku belum terhubung. Buka app FRX TOOLS dan beri izin."
        val cache = (storAfter - storBefore).coerceAtLeast(0)
        return "Cache dibersihkan: $cache MB\nRAM tersedia: $ramBefore → $ramAfter MB"
    }
}

object Tools {
    private const val SHOT_DIR = "/sdcard/Pictures/FRX-Screenshots"

    fun memAvailMb(): Long = try {
        File("/proc/meminfo").readLines()
            .first { it.startsWith("MemAvailable:") }
            .filter { it.isDigit() }.toLong() / 1024
    } catch (_: Exception) { 0L }

    fun freeStorageMb(): Long = try {
        StatFs(Environment.getDataDirectory().path).availableBytes / 1048576
    } catch (_: Exception) { 0L }

    /** Bersihkan cache semua aplikasi + matikan proses latar belakang. Harus dipanggil dari thread background. */
    fun boost(): BoostResult {
        if (!ShellBridge.ready) return BoostResult(false, 0, 0, 0, 0)
        val rb = memAvailMb()
        val sb = freeStorageMb()
        ShellBridge.exec("pm trim-caches 999G")
        ShellBridge.exec("am kill-all")
        Thread.sleep(1500)
        return BoostResult(true, rb, memAvailMb(), sb, freeStorageMb())
    }

    /** Ambil screenshot. Return path file kalau berhasil, null kalau gagal. Thread background. */
    fun screenshot(ctx: Context): String? {
        if (!ShellBridge.ready) return null
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val path = "$SHOT_DIR/FRX_$ts.png"
        ShellBridge.exec("mkdir -p $SHOT_DIR")
        ShellBridge.exec("screencap -p $path")
        val ok = ShellBridge.exec("test -s $path && echo OK").trim() == "OK"
        if (!ok) return null
        MediaScannerConnection.scanFile(ctx.applicationContext, arrayOf(path), arrayOf("image/png"), null)
        return path
    }
}

object Runner {
    fun grafik(ctx: Context, onResult: (String) -> Unit, block: (Grafik) -> Unit) {
        val app = ctx.applicationContext
        if (!ShellBridge.ready) {
            ShellBridge.bind(app)
            onResult("Belum terhubung ke Shizuku. Buka app FRX TOOLS dan beri izin.")
            return
        }
        Thread {
            val sb = StringBuilder()
            val g = Grafik(
                { ShellBridge.exec(it) },
                app.getSharedPreferences("faruq", Context.MODE_PRIVATE),
                { sb.appendLine(it) }
            )
            try { block(g) } catch (e: Exception) { sb.appendLine("ERROR: ${e.message}") }
            Handler(Looper.getMainLooper()).post { onResult(sb.toString().trim()) }
        }.start()
    }
}
