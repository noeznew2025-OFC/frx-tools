package com.faruq.grafik

import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

object CrossControls {
    private fun toggle(ui: Ui, p: SharedPreferences, key: String, on: String, off: String, color: Int): TextView {
        lateinit var b: TextView
        fun paint() {
            val s = p.getBoolean(key, false)
            b.text = if (s) on else off
            b.setTextColor(if (s) Color.parseColor("#001018") else color)
            b.background = ui.ripple(ui.rounded(if (s) color else Theme.CHIP, 12, color))
        }
        b = ui.outlineButton(off, color, Theme.CHIP, 12f, 12) {
            p.edit().putBoolean(key, !p.getBoolean(key, false)).apply()
            paint()
        }
        paint()
        return b
    }

    fun build(ui: Ui, p: SharedPreferences, previewDp: Int = 110): View {
        val ctx = ui.ctx
        val cfg0 = CrossCfg.load(p)
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        val preview = CrosshairView(ctx).apply { cfg = cfg0.copy(ox = 0, oy = 0) }
        val previewBox = FrameLayout(ctx).apply {
            background = ui.rounded(Color.parseColor("#05050C"), 12, Theme.BORDER)
            addView(preview, FrameLayout.LayoutParams(-1, -1))
        }
        fun changed() {
            preview.cfg = CrossCfg.load(p).copy(ox = 0, oy = 0)
            preview.invalidate()
        }
        fun putInt(k: String, v: Int) { p.edit().putInt(k, v).apply(); changed() }

        box.addView(toggle(ui, p, "c_on", "CROSSHAIR: ON", "CROSSHAIR: OFF", Theme.GREEN))
        box.addView(previewBox, ui.lp(-1, ui.dp(previewDp), 10, 0))

        box.addView(ui.text("TAMPILAN", 11f, Theme.MUTED, true), ui.lp(-2, -2, 12, 6))
        val style = ui.Chips(listOf("Titik", "Plus", "Plus+Titik", "Ring", "Ring+Titik", "X"), cfg0.style, 3)
        style.onChange = { putInt("c_style", style.idx) }
        box.addView(style.view)

        box.addView(ui.text("WARNA", 11f, Theme.MUTED, true), ui.lp(-2, -2, 12, 6))
        val colors = listOf("#00E5FF", "#2BE38B", "#FF3B3B", "#FFE600", "#FFFFFF", "#FF3BF0", "#FF9100", "#7C4DFF")
            .map { Color.parseColor(it) }
        val dots = mutableListOf<View>()
        val colorRow = LinearLayout(ctx)
        fun refreshDots() {
            val cur = p.getInt("c_color", cfg0.color)
            dots.forEachIndexed { i, v ->
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(colors[i])
                    if (colors[i] == cur) setStroke(ui.dp(3), Color.WHITE) else setStroke(ui.dp(1), Theme.BORDER)
                }
            }
        }
        colors.forEachIndexed { i, c ->
            val v = View(ctx).apply { setOnClickListener { putInt("c_color", c); refreshDots() } }
            dots.add(v)
            colorRow.addView(v, LinearLayout.LayoutParams(ui.dp(26), ui.dp(26)).apply { marginEnd = ui.dp(6) })
        }
        refreshDots()
        box.addView(colorRow)

        box.addView(ui.seek("Ukuran", 8, 120, cfg0.size, " dp") { putInt("c_size", it) }, ui.lp(-1, -2, 12, 0))
        box.addView(ui.seek("Ketebalan", 1, 8, cfg0.thick, " dp") { putInt("c_thick", it) }, ui.lp(-1, -2, 6, 0))
        box.addView(ui.seek("Transparansi", 20, 100, cfg0.alpha, "%") { putInt("c_alpha", it) }, ui.lp(-1, -2, 6, 0))

        box.addView(ui.text("POSISI", 11f, Theme.MUTED, true), ui.lp(-2, -2, 14, 6))
        box.addView(
            toggle(ui, p, "c_edit", "SELESAI ATUR POSISI", "ATUR POSISI (GESER LINGKARAN)", Theme.CYAN)
        )
        box.addView(
            ui.text(
                "Saat mode atur aktif, geser lingkaran kecil di samping crosshair. Garis putih = titik tengah layar. Floating harus aktif.",
                10f, Theme.MUTED
            ), ui.lp(-1, -2, 6, 6)
        )
        fun nudge(dx: Int, dy: Int) {
            p.edit().putInt("c_ox", p.getInt("c_ox", 0) + dx).putInt("c_oy", p.getInt("c_oy", 0) + dy).apply()
        }
        val pad = LinearLayout(ctx)
        fun nb(label: String, w: Float, onClick: () -> Unit) {
            pad.addView(
                ui.outlineButton(label, Theme.CYAN, Theme.CHIP, 14f, 10) { onClick() },
                LinearLayout.LayoutParams(0, -2, w).apply { marginStart = ui.dp(4) }
            )
        }
        nb("←", 1f) { nudge(-1, 0) }
        nb("↑", 1f) { nudge(0, -1) }
        nb("↓", 1f) { nudge(0, 1) }
        nb("→", 1f) { nudge(1, 0) }
        nb("TENGAH", 1.8f) { p.edit().putInt("c_ox", 0).putInt("c_oy", 0).apply() }
        box.addView(pad)
        return box
    }
}

object BoostControls {
    fun build(ui: Ui, ringDp: Int = 150): View {
        val ctx = ui.ctx
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val ring = BoostView(ctx)
        val res = ui.text("Bersihkan cache dan proses latar belakang supaya RAM lebih lega.", 12f, Theme.MUTED)
            .apply { gravity = Gravity.CENTER }
        var busy = false
        val btn = ui.gradientButton("BERSIHKAN CACHE", 14f, 14) {
            if (!busy) {
                busy = true
                ring.start()
                res.text = "Membersihkan…"
                Thread {
                    val r = try { Tools.boost() } catch (e: Exception) { null }
                    Handler(Looper.getMainLooper()).post {
                        busy = false
                        if (r != null && r.ok) ring.finish() else ring.reset()
                        res.text = r?.summary() ?: "Gagal. Pastikan Shizuku aktif."
                    }
                }.start()
            }
        }
        box.addView(ring, ui.lp(ui.dp(ringDp), ui.dp(ringDp), 4, 8))
        box.addView(res, ui.lp(-1, -2, 0, 10))
        box.addView(btn, ui.lp(-1, -2, 0, 0))
        return box
    }
}
