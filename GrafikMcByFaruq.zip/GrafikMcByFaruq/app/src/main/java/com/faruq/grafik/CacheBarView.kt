package com.faruq.grafik

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import android.view.animation.DecelerateInterpolator

/** Progress bar horizontal untuk animasi clear cache. */
class CacheBarView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var progress = 0f
    private var animator: ValueAnimator? = null

    fun start() {
        animator?.cancel()
        progress = 0f
        animator = ValueAnimator.ofFloat(0f, 0.92f).apply {
            duration = 3500
            interpolator = DecelerateInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun finish() {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(progress, 1f).apply {
            duration = 450
            interpolator = DecelerateInterpolator()
            addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    fun reset() {
        animator?.cancel()
        progress = 0f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val h = height.toFloat()
        val radius = h / 2f
        rect.set(0f, 0f, width.toFloat(), h)
        paint.color = Theme.BORDER
        canvas.drawRoundRect(rect, radius, radius, paint)
        rect.right = width * progress
        paint.shader = android.graphics.LinearGradient(
            0f, 0f, width.toFloat(), 0f,
            Theme.PURPLE, Theme.CYAN, android.graphics.Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(rect, radius, radius, paint)
        paint.shader = null
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }
}
