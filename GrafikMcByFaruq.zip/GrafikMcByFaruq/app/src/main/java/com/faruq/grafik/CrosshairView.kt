package com.faruq.grafik

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.MotionEvent
import android.view.View
import kotlin.math.hypot
import kotlin.math.roundToInt

/** Menggambar crosshair. Saat editMode: ada garis tengah layar + lingkaran kecil untuk menggeser. */
class CrosshairView(ctx: Context) : View(ctx) {
    var cfg: CrossCfg = CrossCfg.load(CrossCfg.prefs(ctx))
    var editMode = false
    var onMoved: ((Int, Int) -> Unit)? = null

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var dragging = false
    private var ddx = 0f
    private var ddy = 0f

    private fun cx() = width / 2f + cfg.ox
    private fun cy() = height / 2f + cfg.oy
    private fun hOff() = cfg.size * d / 2f + 34f * d

    override fun onDraw(canvas: Canvas) {
        val cx = cx()
        val cy = cy()
        val r = cfg.size * d / 2f
        val t = cfg.thick * d
        val a = (cfg.alpha * 255 / 100).coerceIn(0, 255)
        paint.color = Color.argb(a, Color.red(cfg.color), Color.green(cfg.color), Color.blue(cfg.color))
        paint.strokeWidth = t
        paint.strokeCap = Paint.Cap.BUTT
        val gap = r * 0.3f

        when (cfg.style) {
            0 -> {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(cx, cy, maxOf(t * 1.3f, r * 0.15f), paint)
            }
            1, 2 -> {
                paint.style = Paint.Style.STROKE
                canvas.drawLine(cx - r, cy, cx - gap, cy, paint)
                canvas.drawLine(cx + gap, cy, cx + r, cy, paint)
                canvas.drawLine(cx, cy - r, cx, cy - gap, paint)
                canvas.drawLine(cx, cy + gap, cx, cy + r, paint)
                if (cfg.style == 2) {
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, t * 0.9f, paint)
                }
            }
            3, 4 -> {
                paint.style = Paint.Style.STROKE
                canvas.drawCircle(cx, cy, r, paint)
                if (cfg.style == 4) {
                    paint.style = Paint.Style.FILL
                    canvas.drawCircle(cx, cy, t * 0.9f, paint)
                }
            }
            else -> {
                paint.style = Paint.Style.STROKE
                val g = r * 0.2f
                val dd = r * 0.7f
                for (sx in intArrayOf(-1, 1)) for (sy in intArrayOf(-1, 1)) {
                    canvas.drawLine(cx + sx * g, cy + sy * g, cx + sx * dd, cy + sy * dd, paint)
                }
            }
        }

        if (editMode) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = d
            paint.color = Color.parseColor("#66FFFFFF")
            canvas.drawLine(0f, height / 2f, width.toFloat(), height / 2f, paint)
            canvas.drawLine(width / 2f, 0f, width / 2f, height.toFloat(), paint)

            val hx = cx + hOff()
            val hy = cy
            paint.style = Paint.Style.FILL
            paint.color = Color.parseColor("#99000000")
            canvas.drawCircle(hx, hy, 16 * d, paint)
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 2 * d
            paint.color = Theme.CYAN
            canvas.drawCircle(hx, hy, 16 * d, paint)
            paint.strokeWidth = d
            canvas.drawLine(cx + r + 4 * d, hy, hx - 16 * d, hy, paint)
            paint.style = Paint.Style.FILL
            canvas.drawCircle(hx, hy, 3 * d, paint)
            paint.textAlign = Paint.Align.CENTER
            paint.textSize = 11 * d
            canvas.drawText("GESER", hx, hy - 22 * d, paint)
            paint.textAlign = Paint.Align.LEFT
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!editMode) return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val hx = cx() + hOff()
                val hy = cy()
                if (hypot(e.x - hx, e.y - hy) <= 44 * d) {
                    dragging = true
                    ddx = hx - e.x
                    ddy = hy - e.y
                    return true
                }
                return false
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val hx = e.x + ddx
                val hy = e.y + ddy
                cfg = cfg.copy(
                    ox = (hx - hOff() - width / 2f).roundToInt(),
                    oy = (hy - height / 2f).roundToInt()
                )
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                dragging = false
                onMoved?.invoke(cfg.ox, cfg.oy)
                return true
            }
        }
        return dragging
    }
}
