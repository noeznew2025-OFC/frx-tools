package com.faruq.grafik

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/** Tampilan mengambang FRX: bubble logo + panel (Grafik / Crosshair / Boost) + crosshair overlay. */
class OverlayService : Service() {

    companion object {
        const val ACTION_EXIT = "com.faruq.grafik.EXIT"
        @Volatile var running = false
    }

    private val F_BASE = WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_IN_SCREEN or WLP.FLAG_LAYOUT_NO_LIMITS

    private lateinit var wm: WindowManager
    private lateinit var ui: Ui
    private lateinit var cp: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var cross: CrosshairView? = null
    private var crossLp: WLP? = null
    private var bubble: View? = null
    private var panel: View? = null
    private var panelLp: WLP? = null
    private var panelOpen = false
    private var infoText: TextView? = null
    private var listenerSet = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        handler.post { applyCross() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        ui = Ui(this)
        cp = CrossCfg.prefs(this)
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        running = true
        ShellBridge.bind(this)
        cp.edit().putBoolean("c_edit", false).apply()
        addCross()
        addBubble()
        cp.registerOnSharedPreferenceChangeListener(prefListener)
        listenerSet = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_EXIT) shutdown()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    // ---------- lifecycle ----------
    private fun startFg() {
        val ch = "frx_overlay"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "FRX Floating", NotificationManager.IMPORTANCE_LOW))
        val exitPi = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_EXIT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, ch)
            .setSmallIcon(R.drawable.ic_logo_fg)
            .setContentTitle("FRX TOOLS aktif")
            .setContentText("Tampilan mengambang berjalan")
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_logo_fg), "Keluar", exitPi
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun cleanup() {
        running = false
        if (listenerSet) {
            cp.unregisterOnSharedPreferenceChangeListener(prefListener)
            listenerSet = false
        }
        try { if (panelOpen) panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        panelOpen = false
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { cross?.let { wm.removeView(it) } } catch (_: Exception) {}
        bubble = null
        cross = null
        panel = null
        try { cp.edit().putBoolean("c_edit", false).apply() } catch (_: Exception) {}
    }

    private fun shutdown() {
        cleanup()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun overlayLp(w: Int, h: Int, flags: Int) =
        WLP(w, h, WLP.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
        }

    // ---------- crosshair ----------
    private fun addCross() {
        val v = CrosshairView(this)
        val lp = overlayLp(WLP.MATCH_PARENT, WLP.MATCH_PARENT, F_BASE or WLP.FLAG_NOT_TOUCHABLE).apply {
            layoutInDisplayCutoutMode = WLP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        v.onMoved = { ox, oy -> cp.edit().putInt("c_ox", ox).putInt("c_oy", oy).apply() }
        wm.addView(v, lp)
        cross = v
        crossLp = lp
        applyCross()
    }

    private fun applyCross() {
        val v = cross ?: return
        val lp = crossLp ?: return
        val on = cp.getBoolean("c_on", false)
        val edit = cp.getBoolean("c_edit", false)
        v.cfg = CrossCfg.load(cp)
        v.editMode = edit
        v.visibility = if (on || edit) View.VISIBLE else View.GONE
        val want = F_BASE or (if (edit) 0 else WLP.FLAG_NOT_TOUCHABLE)
        if (lp.flags != want) {
            lp.flags = want
            try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
        }
        v.invalidate()
    }

    // ---------- bubble ----------
    private fun addBubble() {
        val iv = ImageView(this).apply {
            setImageResource(R.drawable.ic_logo_fg)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#120A2E"), Color.parseColor("#3B1FB8"), Theme.PURPLE)
            ).apply {
                cornerRadius = ui.dp(14).toFloat()
                setStroke(ui.dp(2), Theme.CYAN)
            }
            alpha = 0.92f
        }
        val lp = overlayLp(ui.dp(46), ui.dp(46), WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_NO_LIMITS).apply {
            x = ui.dp(8)
            y = ui.dp(120)
        }
        var sx = 0f
        var sy = 0f
        var ix = 0
        var iy = 0
        var moved = false
        iv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ix = lp.x; iy = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > ui.dp(6) || abs(dy) > ui.dp(6)) moved = true
                    if (moved) {
                        lp.x = ix + dx
                        lp.y = iy + dy
                        try { wm.updateViewLayout(iv, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(iv, lp)
        bubble = iv
    }

    // ---------- panel ----------
    private fun togglePanel() {
        if (panelOpen) closePanel() else openPanel()
    }

    private fun openPanel() {
        if (panel == null) buildPanel()
        val p = panel ?: return
        val lp = panelLp ?: return
        if (!panelOpen) {
            try { wm.addView(p, lp); panelOpen = true } catch (_: Exception) {}
        }
    }

    private fun closePanel() {
        val p = panel ?: return
        if (panelOpen) {
            try { wm.removeView(p) } catch (_: Exception) {}
            panelOpen = false
        }
    }

    private var dsx = 0f
    private var dsy = 0f
    private var dix = 0
    private var diy = 0

    private fun dragPanel(e: MotionEvent): Boolean {
        val lp = panelLp ?: return false
        val v = panel ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dsx = e.rawX; dsy = e.rawY; dix = lp.x; diy = lp.y }
            MotionEvent.ACTION_MOVE -> {
                lp.x = dix + (e.rawX - dsx).toInt()
                lp.y = diy + (e.rawY - dsy).toInt()
                try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
            }
        }
        return true
    }

    private fun buildPanel() {
        val dm = resources.displayMetrics
        val w = minOf(ui.dp(320), (dm.widthPixels * 0.8f).toInt())
        val h = minOf(ui.dp(430), dm.heightPixels - ui.dp(24))

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ui.rounded(Color.parseColor("#F2080812"), 16, Theme.PURPLE)
            setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(12))
        }

        // header
        val logo = ImageView(this).apply {
            setImageResource(R.drawable.ic_logo_fg)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.parseColor("#120A2E"), Color.parseColor("#3B1FB8"), Theme.PURPLE)
            ).apply { cornerRadius = ui.dp(8).toFloat() }
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(ui.text("FRX TOOLS", 15f, Theme.TXT, true))
            addView(ui.text("GAME PANEL", 10f, Theme.CYAN, true).apply { letterSpacing = 0.15f })
        }
        val minBtn = ui.outlineButton("—", Theme.CYAN, Theme.CHIP, 13f, 6) { closePanel() }
        val exitBtn = ui.outlineButton("EXIT", Theme.RED, Theme.CHIP, 12f, 6) { shutdown() }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(logo, LinearLayout.LayoutParams(ui.dp(34), ui.dp(34)))
        header.addView(titles, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(8) })
        header.addView(minBtn, LinearLayout.LayoutParams(ui.dp(44), -2))
        header.addView(exitBtn, LinearLayout.LayoutParams(ui.dp(56), -2).apply { marginStart = ui.dp(6) })
        header.setOnTouchListener { _, e -> dragPanel(e) }
        root.addView(header)

        // tabs + isi
        val tabs = ui.Chips(listOf("GRAFIK", "CROSSHAIR", "BOOST"), 0)
        val tabGraf = buildGrafikTab()
        val tabCross = CrossControls.build(ui, cp, 90)
        val tabBoost = BoostControls.build(ui, 130)
        tabCross.visibility = View.GONE
        tabBoost.visibility = View.GONE
        val holder = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(tabGraf)
            addView(tabCross)
            addView(tabBoost)
        }
        tabs.onChange = {
            listOf(tabGraf, tabCross, tabBoost).forEachIndexed { i, v ->
                v.visibility = if (i == tabs.idx) View.VISIBLE else View.GONE
            }
        }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(holder)
        }

        // footer: screenshot
        val shot = ui.outlineButton("SCREENSHOT", Theme.CYAN, Theme.CHIP, 13f, 10) { doScreenshot() }
        val info = ui.text("", 10f, Theme.MUTED).apply { maxLines = 3 }
        infoText = info

        root.addView(tabs.view, ui.lp(-1, -2, 8, 8))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(shot, ui.lp(-1, -2, 8, 0))
        root.addView(info, ui.lp(-1, -2, 4, 0))

        panel = root
        panelLp = overlayLp(w, h, WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCH_MODAL or WLP.FLAG_LAYOUT_NO_LIMITS).apply {
            x = ui.dp(64)
            y = ui.dp(8)
        }
    }

    private fun buildGrafikTab(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val game = ui.Chips(Grafik.GAMES.keys.toList(), 1)
        val preset = ui.Chips(listOf("smooth", "pixel", "retro"), 0)
        val lod = ui.Chips(listOf("1", "2", "3", "4"), 1)
        val out = ui.text("Siap.", 10f, Theme.GREEN).apply {
            typeface = Typeface.MONOSPACE
            maxLines = 10
        }
        fun go(block: (Grafik) -> Unit) {
            out.text = "Memproses…"
            Runner.grafik(this, { out.text = it.lines().takeLast(10).joinToString("\n") }, block)
        }

        box.addView(ui.text("GAME", 11f, Theme.MUTED, true), ui.lp(-2, -2, 0, 4))
        box.addView(game.view)
        box.addView(ui.text("PRESET", 11f, Theme.MUTED, true), ui.lp(-2, -2, 10, 4))
        box.addView(preset.view)
        box.addView(ui.text("LOD", 11f, Theme.MUTED, true), ui.lp(-2, -2, 10, 4))
        box.addView(lod.view)

        val row = LinearLayout(this)
        row.addView(
            ui.gradientButton("TERAPKAN", 13f, 12) {
                go { it.apply(game.value, preset.value, lod.value.toInt()) }
            },
            LinearLayout.LayoutParams(0, -2, 2f)
        )
        row.addView(
            ui.outlineButton("OFF", Theme.RED, Theme.CHIP, 12f, 12) { go { it.off(game.value) } },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(6) }
        )
        row.addView(
            ui.outlineButton("STATUS", Theme.GREEN, Theme.CHIP, 12f, 12) { go { it.status(game.value) } },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(6) }
        )
        box.addView(row, ui.lp(-1, -2, 12, 8))
        box.addView(out)
        return box
    }

    // ---------- screenshot ----------
    private fun doScreenshot() {
        val p = panel
        val b = bubble
        p?.visibility = View.INVISIBLE
        b?.visibility = View.INVISIBLE
        handler.postDelayed({
            Thread {
                val path = try { Tools.screenshot(this) } catch (e: Exception) { null }
                handler.post {
                    p?.visibility = View.VISIBLE
                    b?.visibility = View.VISIBLE
                    val msg = if (path != null) {
                        "Screenshot tersimpan di:\n" + path.removePrefix("/sdcard/")
                    } else {
                        "Screenshot gagal. Pastikan Shizuku aktif."
                    }
                    infoText?.text = msg
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            }.start()
        }, 350)
    }
}
