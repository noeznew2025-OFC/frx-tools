package com.faruq.grafik

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as WLP
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale
import kotlin.math.abs

/**
 * Floating FRX (gaya game space):
 *  - bubble logo di tepi layar (bisa digeser, menempel ke sisi)
 *  - menu bawah slide-up: statistik + tombol bulat (Grafik, Crosshair, Boost, Screenshot, DND, Monitor, Exit)
 *  - panel fitur (Grafik / Crosshair) di sisi kanan, bisa digeser & ditutup
 *  - BOOST: menu menutup lalu animasi clear cache otomatis di tengah layar
 *  - HUD monitor (CPU / RAM / baterai) di atas layar
 */
class OverlayService : Service() {

    companion object {
        const val ACTION_EXIT = "com.faruq.grafik.EXIT"
        @Volatile var running = false
        val ORANGE = Color.parseColor("#FF9100")
        val SKY = Color.parseColor("#4FC3F7")
        val LILAC = Color.parseColor("#B39DFF")
    }

    private val F_BASE = WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_IN_SCREEN or WLP.FLAG_LAYOUT_NO_LIMITS
    private val F_FLOAT = WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCH_MODAL or WLP.FLAG_LAYOUT_NO_LIMITS

    private lateinit var wm: WindowManager
    private lateinit var ui: Ui
    private lateinit var cp: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private var cross: CrosshairView? = null
    private var crossLp: WLP? = null
    private var bubble: View? = null
    private var sheet: View? = null
    private var activeKey: String? = null
    private val panelViews = HashMap<String, View>()
    private val panelLps = HashMap<String, WLP>()
    private var listenerSet = false

    private var hudView: TextView? = null
    private var hudOn = false
    @Volatile private var hudBusy = false
    private var dndOn = false
    private var boostCard: View? = null
    private var statRam: TextView? = null
    private var statBat: TextView? = null
    private var statCpu: TextView? = null
    @Volatile private var statBusy = false

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ ->
        handler.post { applyCross() }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Theme.load(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        ui = Ui(this)
        cp = CrossCfg.prefs(this)
        startFg()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        running = true
        ShellBridge.bind(this, true)
        cp.edit().putBoolean("c_on", false).putBoolean("c_edit", false).apply()
        addCross()
        addBubble()
        cp.registerOnSharedPreferenceChangeListener(prefListener)
        listenerSet = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_EXIT) shutdown()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    // ---------- lifecycle ----------
    private fun startFg() {
        val ch = "frx_overlay"
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(ch, "FRX Floating", NotificationManager.IMPORTANCE_LOW))
        val exitPi = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_EXIT),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, ch)
            .setSmallIcon(R.drawable.ic_logo_fg)
            .setContentTitle("FRX TOOLS aktif")
            .setContentText("Tampilan mengambang berjalan")
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, R.drawable.ic_logo_fg), "Keluar", exitPi
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun rm(v: View?) {
        if (v == null) return
        try { wm.removeViewImmediate(v) } catch (_: Exception) {}
    }

    private fun cleanup() {
        running = false
        hudOn = false
        if (listenerSet) {
            cp.unregisterOnSharedPreferenceChangeListener(prefListener)
            listenerSet = false
        }
        rm(sheet); sheet = null
        for (v in panelViews.values) rm(v)
        panelViews.clear()
        activeKey = null
        rm(hudView); hudView = null
        rm(boostCard); boostCard = null
        rm(bubble); bubble = null
        rm(cross); cross = null
        try { cp.edit().putBoolean("c_edit", false).putBoolean("c_on", false).apply() } catch (_: Exception) {}
    }

    private fun shutdown() {
        val restoreDnd = dndOn
        cleanup()
        if (restoreDnd) Thread { Tools.setDnd(false) }.start()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    @Suppress("DEPRECATION")
    private fun screen(): IntArray {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        return intArrayOf(dm.widthPixels, dm.heightPixels)
    }

    private fun overlayLp(w: Int, h: Int, flags: Int) =
        WLP(w, h, WLP.TYPE_APPLICATION_OVERLAY, flags, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
        }

    private fun logoView(): ImageView = ImageView(this).apply {
        setImageResource(R.drawable.ic_logo_fg)
        background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.parseColor("#120A2E"), Color.parseColor("#3B1FB8"), Theme.PURPLE)
        ).apply {
            shape = GradientDrawable.OVAL
            setStroke(ui.dp(2), Theme.CYAN)
        }
    }

    // ---------- crosshair ----------
    private fun addCross() {
        val v = CrosshairView(this)
        val lp = overlayLp(WLP.MATCH_PARENT, WLP.MATCH_PARENT, F_BASE or WLP.FLAG_NOT_TOUCHABLE).apply {
            layoutInDisplayCutoutMode = WLP.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        v.onMoved = { ox, oy -> cp.edit().putInt("c_ox", ox).putInt("c_oy", oy).apply() }
        wm.addView(v, lp)
        cross = v
        crossLp = lp
        applyCross()
    }

    private fun applyCross() {
        val v = cross ?: return
        val lp = crossLp ?: return
        val on = cp.getBoolean("c_on", false)
        val edit = cp.getBoolean("c_edit", false) && on
        v.cfg = CrossCfg.load(cp)
        v.editMode = edit
        v.visibility = if (on) View.VISIBLE else View.GONE
        val want = F_BASE or (if (edit) 0 else WLP.FLAG_NOT_TOUCHABLE)
        if (lp.flags != want) {
            lp.flags = want
            try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
        }
        v.invalidate()
    }

    // ---------- bubble (menempel ke sisi layar) ----------
    private fun addBubble() {
        val iv = logoView().apply { alpha = 0.95f }
        val lp = overlayLp(ui.dp(48), ui.dp(48), WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_LAYOUT_NO_LIMITS).apply {
            x = ui.dp(4)
            y = ui.dp(120)
        }
        var sx = 0f
        var sy = 0f
        var ix = 0
        var iy = 0
        var moved = false
        iv.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ix = lp.x; iy = lp.y; moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - sx).toInt()
                    val dy = (e.rawY - sy).toInt()
                    if (abs(dx) > ui.dp(6) || abs(dy) > ui.dp(6)) moved = true
                    if (moved) {
                        lp.x = ix + dx
                        lp.y = iy + dy
                        try { wm.updateViewLayout(iv, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) snapBubble(iv, lp)
                    else if (sheet != null || activeKey != null) closeAll()
                    else openSheet()
                    true
                }
                else -> false
            }
        }
        wm.addView(iv, lp)
        bubble = iv
    }

    private fun snapBubble(v: View, lp: WLP) {
        val sw = screen()[0]
        val target = if (lp.x + lp.width / 2 < sw / 2) ui.dp(4) else sw - lp.width - ui.dp(4)
        ValueAnimator.ofInt(lp.x, target).apply {
            duration = 200
            addUpdateListener {
                lp.x = it.animatedValue as Int
                try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
            }
            start()
        }
    }

    // ---------- menu bawah (slide-up) ----------
    private fun tile(icon: Int, label: String, ring: Int, size: Int, onClick: (ImageView) -> Unit): LinearLayout {
        val btn = ui.roundButton(icon, ring, size, size / 4) {}
        btn.setOnClickListener { onClick(btn) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        col.addView(btn, LinearLayout.LayoutParams(ui.dp(size), ui.dp(size)))
        col.addView(
            ui.text(label, 9f, Theme.TXT, true).apply { gravity = Gravity.CENTER; maxLines = 1 },
            ui.lp(-2, -2, 5, 0)
        )
        return col
    }

    private fun statChip(title: String): Pair<View, TextView> {
        val v = ui.text("-", 12f, Theme.TXT, true)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = ui.rounded(Color.parseColor("#14142A"), 14, Theme.BORDER)
            setPadding(ui.dp(6), ui.dp(5), ui.dp(6), ui.dp(5))
            addView(ui.text(title, 8f, Theme.MUTED, true).apply { letterSpacing = 0.1f })
            addView(v)
        }
        return Pair(box, v)
    }

    private fun buildSheet(w: Int): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ui.rounded(Color.parseColor("#F0090912"), 26, Theme.PURPLE)
            setPadding(ui.dp(14), ui.dp(10), ui.dp(14), ui.dp(12))
        }
        val titles = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(ui.text("FRX TOOLS", 13f, Theme.TXT, true).apply { letterSpacing = 0.1f })
            addView(ui.text("GAME SPACE", 9f, Theme.CYAN, true).apply { letterSpacing = 0.15f })
        }
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(logoView(), LinearLayout.LayoutParams(ui.dp(28), ui.dp(28)))
        head.addView(titles, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(8) })

        // statistik singkat
        val ram = statChip("RAM")
        val bat = statChip("BATERAI")
        val cpu = statChip("CPU")
        statRam = ram.second
        statBat = bat.second
        statCpu = cpu.second
        for (c in listOf(ram, bat, cpu)) {
            head.addView(c.first, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = ui.dp(6) })
        }
        head.addView(
            ui.roundButton(R.drawable.ic_x, Theme.MUTED, 30, 8) { closeAll() },
            LinearLayout.LayoutParams(ui.dp(30), ui.dp(30))
        )
        root.addView(head)

        val tiles = ArrayList<View>()
        tiles.add(tile(R.drawable.ic_grafik, "GRAFIK", Theme.PURPLE, 48) { openPanel("grafik") })
        tiles.add(tile(R.drawable.ic_cross, "CROSSHAIR", Theme.GREEN, 48) { openPanel("cross") })
        tiles.add(tile(R.drawable.ic_boost, "BOOST", ORANGE, 48) { runBoostOverlay() })
        tiles.add(tile(R.drawable.ic_shot, "SCREENSHOT", Theme.CYAN, 48) { doScreenshot() })
        tiles.add(tile(R.drawable.ic_dnd, "DND", LILAC, 48) { btn -> toggleDnd(btn) }.also { col ->
            (col.getChildAt(0) as ImageView).let { ui.roundStyle(it, LILAC, dndOn) }
        })
        tiles.add(tile(R.drawable.ic_monitor, "MONITOR", SKY, 48) { btn ->
            toggleHud(!hudOn)
            ui.roundStyle(btn, SKY, hudOn)
        }.also { col ->
            (col.getChildAt(0) as ImageView).let { ui.roundStyle(it, SKY, hudOn) }
        })
        tiles.add(tile(R.drawable.ic_exit, "EXIT", Theme.RED, 48) { shutdown() })

        val perRow = ((w - ui.dp(28)) / ui.dp(62)).coerceIn(4, 7)
        tiles.chunked(perRow).forEachIndexed { r, rowTiles ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
            for (t in rowTiles) row.addView(t, LinearLayout.LayoutParams(0, -2, 1f))
            repeat(perRow - rowTiles.size) { row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            root.addView(row, ui.lp(-1, -2, if (r == 0) 10 else 8, 0))
        }
        return root
    }

    private fun openSheet() {
        closePanel(false)
        if (sheet != null) return
        val sw = screen()[0]
        val w = minOf(sw - ui.dp(16), ui.dp(600))
        val v = buildSheet(w)
        val lp = overlayLp(w, WLP.WRAP_CONTENT, F_FLOAT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = ui.dp(10)
        }
        v.translationY = ui.dp(260).toFloat()
        v.alpha = 0f
        try { wm.addView(v, lp) } catch (e: Exception) { return }
        sheet = v
        v.animate().translationY(0f).alpha(1f).setDuration(280)
            .setInterpolator(DecelerateInterpolator()).start()
        handler.post(sheetTick)
    }

    private val sheetTick = object : Runnable {
        override fun run() {
            if (sheet == null) return
            if (!statBusy) {
                statBusy = true
                Thread {
                    val s = try { Tools.stats(this@OverlayService, true) } catch (e: Exception) { null }
                    handler.post {
                        statBusy = false
                        if (s != null && sheet != null) {
                            statRam?.text = String.format(Locale.US, "%.1fG", s.ramFreeMb / 1024f)
                            statBat?.text = "${s.batPct}% ${String.format(Locale.US, "%.0f", s.batTemp)}°"
                            statCpu?.text = (s.cpuPct?.let { "$it%" } ?: "-") +
                                (s.cpuTemp?.let { " " + String.format(Locale.US, "%.0f", it) + "°" } ?: "")
                        }
                    }
                }.start()
            }
            handler.postDelayed(this, 2500)
        }
    }

    private fun closeSheet() {
        val v = sheet ?: return
        sheet = null
        v.animate().cancel()
        v.animate().translationY(ui.dp(260).toFloat()).alpha(0f).setDuration(200)
            .withEndAction { rm(v) }.start()
    }

    private fun closeAll() {
        closeSheet()
        closePanel(true)
    }

    // ---------- DND + HUD ----------
    private fun toggleDnd(btn: ImageView) {
        if (!ShellBridge.ready) {
            Toast.makeText(this, "Shizuku belum terhubung", Toast.LENGTH_SHORT).show()
            return
        }
        val target = !dndOn
        Thread {
            val ok = Tools.setDnd(target)
            handler.post {
                if (ok) {
                    dndOn = target
                    ui.roundStyle(btn, LILAC, dndOn)
                    Toast.makeText(this, if (dndOn) "Jangan Ganggu aktif" else "Jangan Ganggu mati", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "DND gagal di ROM ini", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private val hudTick = object : Runnable {
        override fun run() {
            if (!hudOn) return
            if (!hudBusy) {
                hudBusy = true
                Thread {
                    val s = try { Tools.stats(this@OverlayService, true) } catch (e: Exception) { null }
                    handler.post {
                        hudBusy = false
                        if (s != null && hudOn) {
                            val cpu = (s.cpuPct?.let { "$it%" } ?: "-") +
                                (s.cpuTemp?.let { " " + String.format(Locale.US, "%.0f", it) + "°" } ?: "")
                            hudView?.text = "CPU $cpu  RAM ${String.format(Locale.US, "%.1f", s.ramFreeMb / 1024f)}G  " +
                                "BAT ${s.batPct}% ${String.format(Locale.US, "%.0f", s.batTemp)}°"
                        }
                    }
                }.start()
            }
            handler.postDelayed(this, 2000)
        }
    }

    private fun toggleHud(on: Boolean) {
        if (on == hudOn) return
        hudOn = on
        if (on) {
            val tv = ui.text("…", 10f, Theme.TXT, true).apply {
                typeface = Typeface.MONOSPACE
                setPadding(ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(4))
                background = ui.rounded(Color.parseColor("#CC05050C"), 14, Theme.BORDER)
            }
            val lp = overlayLp(WLP.WRAP_CONTENT, WLP.WRAP_CONTENT, F_BASE or WLP.FLAG_NOT_TOUCHABLE).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                y = ui.dp(6)
            }
            try { wm.addView(tv, lp) } catch (e: Exception) { hudOn = false; return }
            hudView = tv
            handler.post(hudTick)
        } else {
            rm(hudView)
            hudView = null
        }
    }

    // ---------- BOOST: menu menutup, animasi clear cache otomatis ----------
    private fun runBoostOverlay() {
        closeAll()
        if (boostCard != null) return
        if (!ShellBridge.ready) {
            Toast.makeText(this, "Shizuku belum terhubung. Buka app FRX TOOLS.", Toast.LENGTH_LONG).show()
            return
        }
        val ring = BoostView(this)
        val msg = ui.text("Membersihkan…", 12f, Theme.TXT, true).apply { gravity = Gravity.CENTER }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = ui.rounded(Color.parseColor("#F2080812"), 26, ORANGE, 2)
            setPadding(ui.dp(22), ui.dp(16), ui.dp(22), ui.dp(16))
            addView(ui.text("CLEAR CACHE", 12f, ORANGE, true).apply { letterSpacing = 0.15f })
            addView(ring, ui.lp(ui.dp(130), ui.dp(130), 6, 6))
            addView(msg)
        }
        val lp = overlayLp(
            WLP.WRAP_CONTENT, WLP.WRAP_CONTENT,
            WLP.FLAG_NOT_FOCUSABLE or WLP.FLAG_NOT_TOUCHABLE or WLP.FLAG_LAYOUT_NO_LIMITS
        ).apply { gravity = Gravity.CENTER }
        card.alpha = 0f
        card.scaleX = 0.85f
        card.scaleY = 0.85f
        try { wm.addView(card, lp) } catch (e: Exception) { return }
        boostCard = card
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start()
        ring.start()
        Thread {
            val r = try { Tools.boost() } catch (e: Exception) { null }
            handler.post {
                if (r != null && r.ok) ring.finish() else ring.reset()
                msg.text = r?.summary() ?: "Gagal. Pastikan Shizuku aktif."
                handler.postDelayed({
                    val c = boostCard
                    if (c != null) {
                        boostCard = null
                        c.animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(220)
                            .withEndAction { rm(c) }.start()
                    }
                }, 2600)
            }
        }.start()
    }

    // ---------- panel fitur ----------
    private fun buildPanel(key: String): View {
        val title: String
        val icon: Int
        val ring: Int
        val content: View
        if (key == "grafik") {
            title = "GRAFIK"; icon = R.drawable.ic_grafik; ring = Theme.PURPLE
            content = buildGrafikContent()
        } else {
            title = "CROSSHAIR"; icon = R.drawable.ic_cross; ring = Theme.GREEN
            content = CrossControls.build(ui, cp, true)
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = ui.rounded(Color.parseColor("#F2080812"), 22, ring)
            setPadding(ui.dp(12), ui.dp(10), ui.dp(12), ui.dp(12))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        header.addView(
            ui.roundButton(icon, ring, 32, 7) {}.apply { isClickable = false },
            LinearLayout.LayoutParams(ui.dp(32), ui.dp(32))
        )
        header.addView(
            ui.text(title, 14f, Theme.TXT, true).apply { letterSpacing = 0.1f },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(8) }
        )
        header.addView(
            ui.roundButton(R.drawable.ic_x, Theme.RED, 32, 8) { closePanel(true) },
            LinearLayout.LayoutParams(ui.dp(32), ui.dp(32))
        )
        header.setOnTouchListener { _, e -> dragPanel(key, e) }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(content)
        }
        root.addView(header)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = ui.dp(8) })
        return root
    }

    private fun openPanel(key: String) {
        closeSheet()
        if (activeKey == key) return
        closePanel(false)
        val v = panelViews.getOrPut(key) { buildPanel(key) }
        val sc = screen()
        val w = minOf(ui.dp(280), (sc[0] * 0.5f).toInt())
        val h = minOf(ui.dp(360), sc[1] - ui.dp(16))
        val old = panelLps[key]
        val lp = overlayLp(w, h, F_FLOAT)
        lp.x = (old?.x ?: (sc[0] - w - ui.dp(8))).coerceIn(0, maxOf(0, sc[0] - w))
        lp.y = (old?.y ?: ((sc[1] - h) / 2)).coerceIn(0, maxOf(0, sc[1] - h))
        panelLps[key] = lp
        v.animate().cancel()
        rm(v)
        v.alpha = 0f
        v.scaleX = 0.92f
        v.scaleY = 0.92f
        try { wm.addView(v, lp) } catch (e: Exception) { return }
        activeKey = key
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(200).start()
        if (key == "cross") cp.edit().putBoolean("c_edit", true).apply()
    }

    private fun closePanel(animated: Boolean) {
        val key = activeKey ?: return
        activeKey = null
        val v = panelViews[key] ?: return
        if (key == "cross") cp.edit().putBoolean("c_edit", false).apply()
        v.animate().cancel()
        if (animated) {
            v.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f).setDuration(160)
                .withEndAction { rm(v) }.start()
        } else {
            rm(v)
        }
    }

    private var dsx = 0f
    private var dsy = 0f
    private var dix = 0
    private var diy = 0

    private fun dragPanel(key: String, e: MotionEvent): Boolean {
        val lp = panelLps[key] ?: return false
        val v = panelViews[key] ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { dsx = e.rawX; dsy = e.rawY; dix = lp.x; diy = lp.y }
            MotionEvent.ACTION_MOVE -> {
                lp.x = dix + (e.rawX - dsx).toInt()
                lp.y = diy + (e.rawY - dsy).toInt()
                try { wm.updateViewLayout(v, lp) } catch (_: Exception) {}
            }
        }
        return true
    }

    private fun buildGrafikContent(): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val game = ui.Chips(Grafik.GAMES.keys.toList(), 1, 1, 12f)
        val preset = ui.Chips(listOf("smooth", "pixel", "retro"), 0, 3, 12f)
        val lod = ui.Chips(listOf("1", "2", "3", "4"), 1, 4, 12f)
        val out = ui.text("Siap.", 10f, Theme.GREEN).apply {
            typeface = Typeface.MONOSPACE
            maxLines = 10
        }
        fun go(block: (Grafik) -> Unit) {
            out.text = "Memproses…"
            Runner.grafik(this, { out.text = it.lines().takeLast(10).joinToString("\n") }, block)
        }

        box.addView(ui.text("GAME", 11f, Theme.MUTED, true), ui.lp(-2, -2, 0, 4))
        box.addView(game.view)
        box.addView(ui.text("PRESET", 11f, Theme.MUTED, true), ui.lp(-2, -2, 10, 4))
        box.addView(preset.view)
        box.addView(ui.text("LOD", 11f, Theme.MUTED, true), ui.lp(-2, -2, 10, 4))
        box.addView(lod.view)

        box.addView(
            ui.gradientButton("TERAPKAN", 13f, 12) {
                go { it.apply(game.value, preset.value, lod.value.toInt()) }
            },
            ui.lp(-1, -2, 12, 8)
        )
        val row = LinearLayout(this)
        row.addView(
            ui.outlineButton("OFF", Theme.RED, Theme.CHIP, 12f, 11) { go { it.off(game.value) } },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        row.addView(
            ui.outlineButton("STATUS", Theme.GREEN, Theme.CHIP, 12f, 11) { go { it.status(game.value) } },
            LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = ui.dp(6) }
        )
        box.addView(row, ui.lp(-1, -2, 0, 8))
        box.addView(out)
        return box
    }

    // ---------- screenshot ----------
    private fun doScreenshot() {
        closeAll()
        val b = bubble
        b?.visibility = View.INVISIBLE
        handler.postDelayed({
            Thread {
                val path = try { Tools.screenshot(this) } catch (e: Exception) { null }
                handler.post {
                    b?.visibility = View.VISIBLE
                    val msg = if (path != null) {
                        "Screenshot tersimpan di galeri:\n" + path.removePrefix("/sdcard/")
                    } else {
                        "Screenshot gagal. Pastikan Shizuku aktif."
                    }
                    Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                }
            }.start()
        }, 600)
    }
}
