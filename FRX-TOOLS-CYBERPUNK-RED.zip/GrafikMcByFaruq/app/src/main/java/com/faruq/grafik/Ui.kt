package com.faruq.grafik

import android.content.Context
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView

data class ThemeDef(val name: String, val a: Int, val b: Int)

object Theme {
    val BG = Color.parseColor("#090306")
    val CARD = Color.parseColor("#1A080D")
    val CHIP = Color.parseColor("#2A0B12")
    val BORDER = Color.parseColor("#7A1428")
    var PURPLE = Color.parseColor("#FF1744")
    var CYAN = Color.parseColor("#FF526F")
    val TXT = Color.parseColor("#F2F2FA")
    val MUTED = Color.parseColor("#9A9AB8")
    val GREEN = Color.parseColor("#2BE38B")
    val RED = Color.parseColor("#FF1744")

    val THEMES = listOf(
        ThemeDef("CYBER RED", Color.parseColor("#FF1744"), Color.parseColor("#FF526F")),
        ThemeDef("CRIMSON", Color.parseColor("#D50032"), Color.parseColor("#FF7043")),
        ThemeDef("NEON PINK", Color.parseColor("#FF2D75"), Color.parseColor("#FF8A80")),
        ThemeDef("DARK RED", Color.parseColor("#B00020"), Color.parseColor("#FF1744"))
    )
    var index = 0

    fun apply(i: Int) {
        index = i.coerceIn(0, THEMES.size - 1)
        PURPLE = THEMES[index].a
        CYAN = THEMES[index].b
    }

    fun load(ctx: Context) {
        apply(ctx.getSharedPreferences("frx_ui", Context.MODE_PRIVATE).getInt("theme", 0))
    }

    fun save(ctx: Context, i: Int) {
        ctx.getSharedPreferences("frx_ui", Context.MODE_PRIVATE).edit().putInt("theme", i).apply()
        apply(i)
    }
}

data class CrossCfg(
    val style: Int, val color: Int, val size: Int, val thick: Int,
    val alpha: Int, val ox: Int, val oy: Int
) {
    companion object {
        const val FILE = "frx_cross"
        fun prefs(ctx: Context): SharedPreferences =
            ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

        fun load(p: SharedPreferences) = CrossCfg(
            p.getInt("c_style", 1),
            p.getInt("c_color", Color.parseColor("#FF1744")),
            p.getInt("c_size", 36),
            p.getInt("c_thick", 2),
            p.getInt("c_alpha", 100),
            p.getInt("c_ox", 0),
            p.getInt("c_oy", 0)
        )
    }
}

class Ui(val ctx: Context) {
    fun dp(v: Int) = (v * ctx.resources.displayMetrics.density).toInt()

    fun rounded(color: Int, r: Int, stroke: Int = 0, sw: Int = 1) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
        if (stroke != 0) setStroke(dp(sw), stroke)
    }

    fun ripple(bg: GradientDrawable) = RippleDrawable(ColorStateList.valueOf(0x33FFFFFF), bg, null)

    fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(color)
        typeface = if (bold) Typeface.create("sans-serif-medium", Typeface.BOLD) else Typeface.SANS_SERIF
    }

    fun lp(w: Int, h: Int, top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top); bottomMargin = dp(bottom) }

    fun gradientButton(t: String, size: Float = 15f, pad: Int = 16, onClick: () -> Unit) = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        letterSpacing = 0.1f
        setPadding(0, dp(pad), 0, dp(pad))
        background = ripple(
            GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Theme.PURPLE, Theme.CYAN)
            ).apply { cornerRadius = dp(14).toFloat() }
        )
        setOnClickListener { onClick() }
    }

    fun outlineButton(
        t: String, color: Int, fill: Int, size: Float = 13f, pad: Int = 14, onClick: () -> Unit
    ) = TextView(ctx).apply {
        text = t
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        setPadding(dp(4), dp(pad), dp(4), dp(pad))
        background = ripple(rounded(fill, 14, color))
        setOnClickListener { onClick() }
    }

    fun seek(label: String, lo: Int, hi: Int, value: Int, unit: String, onChange: (Int) -> Unit): View {
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val head = LinearLayout(ctx)
        val valueView = text("$value$unit", 12f, Theme.TXT, true)
        head.addView(text(label, 12f, Theme.MUTED), LinearLayout.LayoutParams(0, -2, 1f))
        head.addView(valueView)
        val bar = SeekBar(ctx)
        bar.max = hi - lo
        bar.progress = value - lo
        bar.progressTintList = ColorStateList.valueOf(Theme.PURPLE)
        bar.thumbTintList = ColorStateList.valueOf(Theme.CYAN)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                valueView.text = "${p + lo}$unit"
                if (fromUser) onChange(p + lo)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(head)
        box.addView(bar, lp(-1, -2, 2, 0))
        return box
    }

    fun circleBg(fill: Int, ring: Int, ringDp: Int = 2) = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(fill)
        setStroke(dp(ringDp), ring)
    }

    private fun ovalMask() = GradientDrawable().apply {
        shape = GradientDrawable.OVAL
        setColor(Color.WHITE)
    }

    /** Tombol bulat dengan ikon. */
    fun roundButton(iconRes: Int, ring: Int, sizeDp: Int = 52, padDp: Int = 13, onClick: () -> Unit): ImageView =
        ImageView(ctx).apply {
            setImageResource(iconRes)
            setColorFilter(ring)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(padDp), dp(padDp), dp(padDp), dp(padDp))
            background = RippleDrawable(
                ColorStateList.valueOf(0x44FFFFFF),
                circleBg(Color.parseColor("#1B1B3A"), ring),
                ovalMask()
            )
            setOnClickListener { onClick() }
        }

    /** Ubah tampilan tombol bulat (aktif / tidak). */
    fun roundStyle(iv: ImageView, ring: Int, on: Boolean) {
        val fill = if (on) Color.argb(0x66, Color.red(ring), Color.green(ring), Color.blue(ring)) else Color.parseColor("#1B1B3A")
        iv.setColorFilter(if (on) Color.WHITE else ring)
        iv.background = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), circleBg(fill, ring), ovalMask())
    }

    /** Tombol bulat berisi teks (mis. panah). */
    fun roundText(t: String, ring: Int, ts: Float = 14f, onClick: () -> Unit) = TextView(ctx).apply {
        text = t
        textSize = ts
        setTextColor(ring)
        gravity = Gravity.CENTER
        typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        background = RippleDrawable(ColorStateList.valueOf(0x44FFFFFF), circleBg(Theme.CHIP, ring, 1), ovalMask())
        setOnClickListener { onClick() }
    }

    /** Tombol bulat + nama fitur di bawahnya (gaya game panel). */
    fun menuItem(iconRes: Int, label: String, ring: Int, sizeDp: Int = 52, labelSize: Float = 10f, onClick: () -> Unit): LinearLayout =
        LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(roundButton(iconRes, ring, sizeDp, sizeDp / 4, onClick), LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)))
            addView(
                text(label, labelSize, Theme.TXT, true).apply {
                    gravity = Gravity.CENTER
                    maxLines = 1
                    letterSpacing = 0.03f
                },
                lp(-2, -2, 6, 0)
            )
            setOnClickListener { onClick() }
        }

    /** Baris/grid pilihan (chip). */
    inner class Chips(val opts: List<String>, start: Int, perRow: Int = opts.size, private val tsize: Float = 13f) {
        var idx = start
        var onChange: (() -> Unit)? = null
        val value get() = opts[idx]
        private val views = mutableListOf<TextView>()
        val view = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }

        init {
            opts.chunked(perRow).forEachIndexed { r, rowOpts ->
                val row = LinearLayout(ctx)
                rowOpts.forEachIndexed { c, o ->
                    val i = r * perRow + c
                    val tv = text(o, tsize, Theme.MUTED, true).apply {
                        gravity = Gravity.CENTER
                        setPadding(dp(4), dp(11), dp(4), dp(11))
                        setOnClickListener { idx = i; refresh(); onChange?.invoke() }
                    }
                    row.addView(tv, LinearLayout.LayoutParams(0, -2, 1f).apply { if (c > 0) marginStart = dp(6) })
                    views.add(tv)
                }
                repeat(perRow - rowOpts.size) {
                    row.addView(View(ctx), LinearLayout.LayoutParams(0, 1, 1f).apply { marginStart = dp(6) })
                }
                view.addView(row, lp(-1, -2, if (r > 0) 6 else 0, 0))
            }
            refresh()
        }

        fun select(i: Int) {
            idx = i
            refresh()
        }

        fun refresh() = views.forEachIndexed { i, tv ->
            if (i == idx) {
                tv.background = ripple(rounded(Theme.PURPLE, 12))
                tv.setTextColor(Color.WHITE)
            } else {
                tv.background = ripple(rounded(Theme.CHIP, 12, Theme.BORDER))
                tv.setTextColor(Theme.MUTED)
            }
        }
    }
}
